package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import kotlin.math.*

const val MATCH = -1
const val WRAP = -2
fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun roundBg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

object Prefs {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("neon", 0) }
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun si(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun sb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    var wallpaper: Int get() = i("wp", 0); set(v) = si("wp", v)
    var shape: Int get() = i("shape", 1); set(v) = si("shape", v)
    var iconSize: Int get() = i("size", 56); set(v) = si("size", v)
    var columns: Int get() = i("cols", 4); set(v) = si("cols", v)
    var dim: Int get() = i("dim", 25); set(v) = si("dim", v)
    var drawerAlpha: Int get() = i("dalpha", 85); set(v) = si("dalpha", v)
    var accent: Int get() = i("accent", 0xFFFF2DF5.toInt()); set(v) = si("accent", v)
    var labels: Boolean get() = b("labels", true); set(v) = sb("labels", v)
    var glow: Boolean get() = b("glow", true); set(v) = sb("glow", v)
    var clock24: Boolean get() = b("c24", false); set(v) = sb("c24", v)
    fun list(k: String): List<String> = sp.getString(k, "")!!.split("|").filter { it.isNotEmpty() }
    fun setList(k: String, l: List<String>) = sp.edit().putString(k, l.joinToString("|")).apply()
}

class AppInfo(val label: String, val pkg: String, val cmp: ComponentName)

object Apps {
    fun load(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map {
            AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, ComponentName(it.activityInfo.packageName, it.activityInfo.name))
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
    fun launch(c: Context, a: AppInfo) {
        try {
            c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cmp)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) { Toast.makeText(c, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show() }
    }
}

object IconShaper {
    val names = listOf("دائرة", "سكويركل", "مربع دائري", "مربع", "قطرة", "سداسي")

    fun path(shape: Int, r: RectF): Path {
        val p = Path(); val w = r.width()
        when (shape) {
            0 -> p.addOval(r, Path.Direction.CW)
            1 -> {
                val cx = r.centerX().toDouble(); val cy = r.centerY().toDouble(); val a = w / 2.0
                for (i in 0..120) {
                    val t = i * 2 * PI / 120; val c = cos(t); val s = sin(t)
                    val x = (cx + a * sign(c) * sqrt(abs(c))).toFloat(); val y = (cy + a * sign(s) * sqrt(abs(s))).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            2 -> p.addRoundRect(r, w * 0.24f, w * 0.24f, Path.Direction.CW)
            3 -> p.addRoundRect(r, w * 0.06f, w * 0.06f, Path.Direction.CW)
            4 -> { val b = w / 2; val s = w * 0.08f; p.addRoundRect(r, floatArrayOf(b, b, b, b, b, b, s, s), Path.Direction.CW) }
            else -> {
                val a = w / 2.0
                for (i in 0..5) {
                    val t = PI / 3 * i - PI / 2
                    val x = (r.centerX() + a * cos(t)).toFloat(); val y = (r.centerY() + a * sin(t)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }

    fun render(d: Drawable, size: Int, shape: Int, accent: Int, glow: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pad = size * (if (glow) 0.07f else 0.02f)
        val path = path(shape, RectF(pad, pad, size - pad, size - pad))
        if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = size * 0.05f; color = accent
            maskFilter = BlurMaskFilter(size * 0.05f, BlurMaskFilter.Blur.NORMAL)
        })
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B1B26") })
        c.save(); c.clipPath(path)
        if (d is AdaptiveIconDrawable) {
            val o = (size * 0.25f).toInt(); d.setBounds(-o, -o, size + o, size + o)
        } else {
            val o = (size * 0.2f).toInt(); d.setBounds(o, o, size - o, size - o)
        }
        d.draw(c); c.restore()
        if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = size * 0.025f; color = accent; strokeJoin = Paint.Join.ROUND
        })
        return bmp
    }
}

object Icons {
    private val cache = HashMap<String, Bitmap>()
    @Synchronized fun clear() = cache.clear()
    @Synchronized fun get(c: Context, a: AppInfo, px: Int): Bitmap = cache.getOrPut(a.pkg) {
        val pm = c.packageManager
        val d = try { pm.getActivityIcon(a.cmp) } catch (e: Exception) { pm.defaultActivityIcon }
        IconShaper.render(d, px, Prefs.shape, Prefs.accent, Prefs.glow)
    }
}

object Util {
    const val WP_COUNT = 20
    fun wpId(c: Context, i: Int) = c.resources.getIdentifier("wp%02d".format(i + 1), "drawable", c.packageName)
    fun decode(c: Context, i: Int, w: Int): Bitmap {
        val id = wpId(c, i)
        if (id != 0) try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(c.resources, id, o)
            var s = 1
            while (o.outWidth > 0 && o.outWidth / (s * 2) >= w) s *= 2
            val bmp = BitmapFactory.decodeResource(c.resources, id, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp != null) return bmp
        } catch (e: Throwable) {}
        // بديل احتياطي: خلفية متدرجة إذا لم تتوفر الصورة
        val h = w * 16 / 9
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val hue = (i * 47f) % 360f
        val p = Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                Color.HSVToColor(floatArrayOf(hue, 0.8f, 0.55f)),
                Color.HSVToColor(floatArrayOf((hue + 60f) % 360f, 0.9f, 0.12f)), Shader.TileMode.CLAMP)
        }
        Canvas(bm).drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return bm
    }
    fun round(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, r.toFloat()) }
        }
        v.clipToOutline = true
    }
    fun pickWallpaper(a: Activity, done: () -> Unit) {
        val sv = HorizontalScrollView(a); val row = LinearLayout(a)
        row.setPadding(a.dp(8), a.dp(8), a.dp(8), a.dp(8)); sv.addView(row)
        val dlg = AlertDialog.Builder(a).setTitle("اختر الخلفية").setView(sv).create()
        for (i in 0 until WP_COUNT) {
            val iv = ImageView(a)
            iv.layoutParams = LinearLayout.LayoutParams(a.dp(90), a.dp(160)).apply { setMargins(a.dp(4), 0, a.dp(4), 0) }
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decode(a, i, 200)); round(iv, a.dp(12))
            iv.setOnClickListener { Prefs.wallpaper = i; dlg.dismiss(); done() }
            row.addView(iv)
        }
        dlg.show()
    }
    fun setSystemWallpaper(a: Activity) {
        Toast.makeText(a, "جارٍ التعيين…", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try { WallpaperManager.getInstance(a).setBitmap(decode(a, Prefs.wallpaper, 1080)); "تم تعيين الخلفية ✓" }
            catch (e: Exception) { "تعذر تعيين الخلفية" }
            a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() }
        }.start()
    }
}
