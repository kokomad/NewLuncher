package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import java.util.Locale
import kotlin.math.*

const val MATCH = -1
const val WRAP = -2
fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun roundBg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }
fun isAr() = Locale.getDefault().language == "ar"
val DEFAULT_ACCENT = 0xFFFF8A00.toInt()
fun neoDrawable(r: Float, stroke: Int, strokeW: Int, c1: Int = 0xFF222226.toInt(), c2: Int = 0xFF0C0C0E.toInt()) =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = r; setStroke(strokeW, stroke) }

object Prefs {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("neon", 0) }
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun si(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun sb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    var wallpaper: Int get() = i("wp", 0); set(v) = si("wp", v)
    var shape: Int get() = i("shape", 2); set(v) = si("shape", v)
    var iconSize: Int get() = i("size", 60); set(v) = si("size", v)
    var columns: Int get() = i("cols", 4); set(v) = si("cols", v)
    var dim: Int get() = i("dim", 25); set(v) = si("dim", v)
    var drawerAlpha: Int get() = i("dalpha", 85); set(v) = si("dalpha", v)
    var accent: Int get() = i("accent", DEFAULT_ACCENT); set(v) = si("accent", v)
    var labels: Boolean get() = b("labels", true); set(v) = sb("labels", v)
    var glow: Boolean get() = b("glow", true); set(v) = sb("glow", v)
    var clock24: Boolean get() = b("c24", false); set(v) = sb("c24", v)
    var tile: Int get() = i("tile", 3); set(v) = si("tile", v)
    var wpVer: Int get() = i("wpver", 0); set(v) = si("wpver", v)
    var wpDay: Int get() = i("wpday", 0); set(v) = si("wpday", v)
    var clockStyle: Int get() = i("cstyle", 0); set(v) = si("cstyle", v)
    var clockSize: Int get() = i("csize", 72); set(v) = si("csize", v)
    var showSearch: Boolean get() = b("showsearch", true); set(v) = sb("showsearch", v)
    var showDock: Boolean get() = b("showdock", true); set(v) = sb("showdock", v)
    var showBattery: Boolean get() = b("showbat", true); set(v) = sb("showbat", v)
    var hideStatus: Boolean get() = b("hidestatus", false); set(v) = sb("hidestatus", v)
    var blur: Int get() = i("blur", 0); set(v) = si("blur", v)
    var drawerBlur: Boolean get() = b("dblur", true); set(v) = sb("dblur", v)
    var autoWp: Boolean get() = b("autowp", false); set(v) = sb("autowp", v)
    var sortMode: Int get() = i("sort", 0); set(v) = si("sort", v)
    var suggest: Boolean get() = b("suggest", true); set(v) = sb("suggest", v)
    var labelSize: Int get() = i("lsize", 11); set(v) = si("lsize", v)
    var doubleTap: Int get() = i("dtap", 0); set(v) = si("dtap", v)
    var swipeDown: Int get() = i("sdown", 0); set(v) = si("sdown", v)
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun ss(k: String, v: String) = sp.edit().putString(k, v).apply()
    var userName: String get() = s("uname", ""); set(v) = ss("uname", v)
    var cityManual: String get() = s("cityman", ""); set(v) = ss("cityman", v)
    var customQuote: String get() = s("cquote", ""); set(v) = ss("cquote", v)
    var bgMode: Int get() = i("bgmode", 0); set(v) = si("bgmode", v)
    var cardClock: Int get() = i("cardclock", 0); set(v) = si("cardclock", v)
    var quoteMode: Int get() = i("qmode", 0); set(v) = si("qmode", v)
    var quoteOffset: Int get() = i("qoff", 0); set(v) = si("qoff", v)
    var searchEngine: Int get() = i("engine", 0); set(v) = si("engine", v)
    var showCard: Boolean get() = b("showcard", true); set(v) = sb("showcard", v)
    var showWeather: Boolean get() = b("showweather", true); set(v) = sb("showweather", v)
    var tempF: Boolean get() = b("tempf", false); set(v) = sb("tempf", v)
    var themedIcons: Boolean get() = b("themed", false); set(v) = sb("themed", v)
    var haptics: Boolean get() = b("haptics", true); set(v) = sb("haptics", v)
    var showNav: Boolean get() = b("shownav", true); set(v) = sb("shownav", v)
    var alphaIndex: Boolean get() = b("alphaidx", true); set(v) = sb("alphaidx", v)
    var cubePages: Boolean get() = b("cubepages", true); set(v) = sb("cubepages", v)
    var glIcons: Boolean get() = b("glicons", true); set(v) = sb("glicons", v)
    var fx3d: Boolean get() = b("fx3d", true); set(v) = sb("fx3d", v)
    var parallax: Boolean get() = b("parallax", true); set(v) = sb("parallax", v)
    var tilt: Boolean get() = b("tilt", true); set(v) = sb("tilt", v)
    var fxPower: Int get() = i("fxpower", 50); set(v) = si("fxpower", v)
    fun uses(pkg: String) = sp.getInt("u_$pkg", 0)
    fun list(k: String): List<String> = sp.getString(k, "")!!.split("|").filter { it.isNotEmpty() }
    fun setList(k: String, l: List<String>) = sp.edit().putString(k, l.joinToString("|")).apply()
}

class AppInfo(val label: String, val pkg: String, val cmp: ComponentName, val installed: Long = 0L)

object Apps {
    fun load(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        Prefs.init(c)
        return pm.queryIntentActivities(i, 0).map {
            val pkg = it.activityInfo.packageName
            val inst = try { pm.getPackageInfo(pkg, 0).firstInstallTime } catch (e: Exception) { 0L }
            AppInfo(Prefs.sp.getString("ren_$pkg", null) ?: it.loadLabel(pm).toString(), pkg, ComponentName(pkg, it.activityInfo.name), inst)
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
    fun launch(c: Context, a: AppInfo) {
        try { Prefs.sp.edit().putInt("u_${a.pkg}", Prefs.uses(a.pkg) + 1).apply() } catch (e: Exception) {}
        try {
            c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cmp)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) { Toast.makeText(c, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show() }
    }
}

object IconShaper {
    val names = listOf("دائرة", "سكويركل", "مربع دائري", "مربع", "قطرة", "سداسي")

    fun path(shape: Int, r: RectF): Path {
        val p = Path(); val w = r.width()
        when (shape) {
            0 -> p.addOval(r, Path.Direction.CW)
            1 -> {
                val cx = r.centerX().toDouble(); val cy = r.centerY().toDouble(); val a = w / 2.0
                for (i in 0..120) {
                    val t = i * 2 * PI / 120; val c = cos(t); val s = sin(t)
                    val x = (cx + a * sign(c) * sqrt(abs(c))).toFloat(); val y = (cy + a * sign(s) * sqrt(abs(s))).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            2 -> p.addRoundRect(r, w * 0.24f, w * 0.24f, Path.Direction.CW)
            3 -> p.addRoundRect(r, w * 0.06f, w * 0.06f, Path.Direction.CW)
            4 -> { val b = w / 2; val s = w * 0.08f; p.addRoundRect(r, floatArrayOf(b, b, b, b, b, b, s, s), Path.Direction.CW) }
            else -> {
                val a = w / 2.0
                for (i in 0..5) {
                    val t = PI / 3 * i - PI / 2
                    val x = (r.centerX() + a * cos(t)).toFloat(); val y = (r.centerY() + a * sin(t)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }

    fun render(d: Drawable, size: Int, shape: Int, accent: Int, glow: Boolean, tile: Int = 0, themed: Boolean = false, bare: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val neo = tile == 3
        val d3 = tile == 4
        val shift = if (d3) -size * 0.025f else 0f
        val pad = size * (if (d3) 0.13f else if (neo) 0.11f else if (glow) 0.07f else 0.02f)
        val rect = RectF(pad, pad, size - pad, size - pad)
        val path = path(shape, rect)
        if (d3) {
            // ثلاثي الأبعاد: ظل + بثق بعمق + وجه علوي مضيء
            val depth = size * 0.05f
            val sh = Path(path); sh.offset(depth * 0.6f, depth * 1.5f)
            c.drawPath(sh, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xDD000000.toInt(); maskFilter = BlurMaskFilter(size * 0.07f, BlurMaskFilter.Blur.NORMAL)
            })
            val side = Color.rgb((Color.red(accent) * 0.32f).toInt(), (Color.green(accent) * 0.32f).toInt(), (Color.blue(accent) * 0.32f).toInt())
            val steps = 8
            for (t in steps downTo 1) {
                val ex = Path(path); val o = shift + depth * t / steps; ex.offset(o, o)
                c.drawPath(ex, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = side })
            }
            c.save(); c.translate(shift, shift)
            if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.04f
                color = (accent and 0x00FFFFFF) or 0x80000000.toInt()
                maskFilter = BlurMaskFilter(size * 0.04f, BlurMaskFilter.Blur.NORMAL)
            })
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    0xFF3E3E46.toInt(), 0xFF141418.toInt(), Shader.TileMode.CLAMP)
            })
        } else if (neo) {
            // ظل ناعم + وجه داكن بتدرج + إطار مضيء (نيومورفيك)
            val sh = Path(path); sh.offset(size * 0.025f, size * 0.04f)
            if (!bare) c.drawPath(sh, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xCC000000.toInt(); maskFilter = BlurMaskFilter(size * 0.06f, BlurMaskFilter.Blur.NORMAL)
            })
            if (glow && !bare) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.04f
                color = (accent and 0x00FFFFFF) or 0x80000000.toInt()
                maskFilter = BlurMaskFilter(size * 0.04f, BlurMaskFilter.Blur.NORMAL)
            })
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    0xFF303036.toInt(), 0xFF111113.toInt(), Shader.TileMode.CLAMP)
            })
        } else {
            if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.05f; color = accent
                maskFilter = BlurMaskFilter(size * 0.05f, BlurMaskFilter.Blur.NORMAL)
            })
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                when (tile) {
                    1 -> shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(),
                        (accent and 0x00FFFFFF) or 0x99000000.toInt(), Color.parseColor("#12121C"), Shader.TileMode.CLAMP)
                    2 -> color = 0x33FFFFFF
                    else -> color = Color.parseColor("#1B1B26")
                }
            })
        }
        c.save(); c.clipPath(path)
        var drawn = false
        if (themed && Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable) {
            val m = d.monochrome
            if (m != null) {
                val mm = m.mutate(); mm.setTint(accent)
                val i = (size * 0.04f).toInt(); mm.setBounds(i, i, size - i, size - i); mm.draw(c); drawn = true
            }
        }
        if (!drawn) {
            if (d is AdaptiveIconDrawable) {
                val o = (size * 0.25f).toInt(); d.setBounds(-o, -o, size + o, size + o)
            } else {
                val o = (size * 0.2f).toInt(); d.setBounds(o, o, size - o, size - o)
            }
            d.draw(c)
        }
        if (d3) c.drawOval(RectF(rect.left, rect.top - rect.height() * 0.25f, rect.right, rect.centerY()),
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, rect.top, 0f, rect.centerY(), 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            })
        c.restore()
        if (d3) {
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.022f
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    0x99FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            })
            if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.014f
                color = (accent and 0x00FFFFFF) or 0xCC000000.toInt()
            })
            c.restore()
        } else if (neo) {
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.018f
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            })
            if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = size * 0.016f
                color = (accent and 0x00FFFFFF) or 0xAA000000.toInt()
            })
        } else if (glow) c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = size * 0.025f; color = accent; strokeJoin = Paint.Join.ROUND
        })
        return bmp
    }
}

object Icons {
    private val cache = HashMap<String, Bitmap>()
    private val bareCache = HashMap<String, Bitmap>()
    @Synchronized fun clear() { cache.clear(); bareCache.clear() }
    /** وجه الأيقونة بدون ظل (لعرض OpenGL) */
    @Synchronized fun getBare(c: Context, a: AppInfo, px: Int): Bitmap = bareCache.getOrPut(a.pkg) {
        val pm = c.packageManager
        val d = try { pm.getActivityIcon(a.cmp) } catch (e: Exception) { pm.defaultActivityIcon }
        IconShaper.render(d, px, Prefs.shape, Prefs.accent, Prefs.glow, 3, Prefs.themedIcons, true)
    }
    @Synchronized fun get(c: Context, a: AppInfo, px: Int): Bitmap = cache.getOrPut(a.pkg) {
        val pm = c.packageManager
        val d = try { pm.getActivityIcon(a.cmp) } catch (e: Exception) { pm.defaultActivityIcon }
        IconShaper.render(d, px, Prefs.shape, Prefs.accent, Prefs.glow, Prefs.tile, Prefs.themedIcons)
    }
}

object Util {
    const val WP_COUNT = 20
    fun wpId(c: Context, i: Int) = c.resources.getIdentifier("wp%02d".format(i + 1), "drawable", c.packageName)
    fun decode(c: Context, i: Int, w: Int): Bitmap {
        if (i < 0) try {
            val f = customFile(c)
            if (f.exists()) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (o.outWidth > 0 && o.outWidth / (s * 2) >= w) s *= 2
                val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
                if (bmp != null) return bmp
            }
        } catch (e: Throwable) {}
        val id = wpId(c, maxOf(i, 0))
        if (id != 0) try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(c.resources, id, o)
            var s = 1
            while (o.outWidth > 0 && o.outWidth / (s * 2) >= w) s *= 2
            val bmp = BitmapFactory.decodeResource(c.resources, id, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp != null) return bmp
        } catch (e: Throwable) {}
        // بديل احتياطي: خلفية متدرجة إذا لم تتوفر الصورة
        val h = w * 16 / 9
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val hue = (i * 47f) % 360f
        val p = Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                Color.HSVToColor(floatArrayOf(hue, 0.8f, 0.55f)),
                Color.HSVToColor(floatArrayOf((hue + 60f) % 360f, 0.9f, 0.12f)), Shader.TileMode.CLAMP)
        }
        Canvas(bm).drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return bm
    }
    fun round(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, r.toFloat()) }
        }
        v.clipToOutline = true
    }
    fun exportPrefs(): String {
        val o = org.json.JSONObject()
        for ((k, v) in Prefs.sp.all) { if (k == "crash") continue; if (v is Boolean || v is Int || v is Long || v is String) o.put(k, v) }
        return o.toString()
    }
    fun importPrefs(json: String): Boolean = try {
        val o = org.json.JSONObject(json); val e = Prefs.sp.edit()
        for (k in o.keys()) {
            when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is String -> e.putString(k, v)
            }
        }
        e.apply(); true
    } catch (t: Throwable) { false }

    const val REQ_GALLERY = 7701
    var pendingDone: (() -> Unit)? = null
    fun customFile(c: Context) = java.io.File(c.filesDir, "custom_wp.jpg")

    fun pickFromGallery(a: Activity, done: () -> Unit) {
        pendingDone = done
        try {
            a.startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_GALLERY)
        } catch (e: Exception) { Toast.makeText(a, "لا يوجد تطبيق معرض", Toast.LENGTH_SHORT).show() }
    }

    fun onGalleryResult(a: Activity, req: Int, res: Int, data: Intent?) {
        if (req != REQ_GALLERY || res != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(a, "جارٍ تطبيق الصورة…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth > 0 && o.outWidth / (s * 2) >= 1440) s *= 2
                val bmp = a.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }
                if (bmp == null) false else {
                    java.io.FileOutputStream(customFile(a)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    Prefs.wallpaper = -1; Prefs.wpVer = Prefs.wpVer + 1; true
                }
            } catch (e: Throwable) { false }
            a.runOnUiThread {
                if (ok) pendingDone?.invoke() else Toast.makeText(a, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    fun pickWallpaper(a: Activity, done: () -> Unit) {
        val sv = HorizontalScrollView(a); val row = LinearLayout(a)
        row.setPadding(a.dp(8), a.dp(8), a.dp(8), a.dp(8)); sv.addView(row)
        val dlg = AlertDialog.Builder(a).setTitle("اختر الخلفية").setView(sv).create()
        val g = TextView(a).apply {
            text = "📷\nمن المعرض"; gravity = android.view.Gravity.CENTER; setTextColor(Color.WHITE); textSize = 13f
            background = GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = a.dp(12).toFloat(); setStroke(a.dp(1), Prefs.accent) }
            layoutParams = LinearLayout.LayoutParams(a.dp(90), a.dp(160)).apply { setMargins(a.dp(4), 0, a.dp(4), 0) }
            setOnClickListener { dlg.dismiss(); pickFromGallery(a, done) }
        }
        row.addView(g)
        if (customFile(a).exists()) {
            val iv = ImageView(a)
            iv.layoutParams = LinearLayout.LayoutParams(a.dp(90), a.dp(160)).apply { setMargins(a.dp(4), 0, a.dp(4), 0) }
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decode(a, -1, 200)); round(iv, a.dp(12))
            iv.setOnClickListener { Prefs.wallpaper = -1; Prefs.wpVer = Prefs.wpVer + 1; dlg.dismiss(); done() }
            row.addView(iv)
        }
        for (i in 0 until WP_COUNT) {
            val iv = ImageView(a)
            iv.layoutParams = LinearLayout.LayoutParams(a.dp(90), a.dp(160)).apply { setMargins(a.dp(4), 0, a.dp(4), 0) }
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decode(a, i, 200)); round(iv, a.dp(12))
            iv.setOnClickListener { Prefs.wallpaper = i; dlg.dismiss(); done() }
            row.addView(iv)
        }
        dlg.show()
    }
    fun setSystemWallpaper(a: Activity) {
        Toast.makeText(a, "جارٍ التعيين…", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try { WallpaperManager.getInstance(a).setBitmap(decode(a, Prefs.wallpaper, 1080)); "تم تعيين الخلفية ✓" }
            catch (e: Exception) { "تعذر تعيين الخلفية" }
            a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() }
        }.start()
    }
}


/** حاسبة فورية داخل البحث: 2+3*4 ، (5+5)/2 ، 2^8 ... */
object Calc {
    fun eval(src: String): String? {
        val s = src.replace(" ", "").replace('×', '*').replace('÷', '/')
        if (s.length < 3 || !s.any { it.isDigit() } || !s.any { it in "+-*/^%" }) return null
        if (!s.all { it.isDigit() || it in "+-*/^%()." }) return null
        return try {
            val v = Parser(s).parse()
            if (v.isNaN() || v.isInfinite()) null else fmt(v)
        } catch (e: Throwable) { null }
    }

    private fun fmt(v: Double): String =
        if (v == Math.floor(v) && abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalStateException(); return v }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i]; i++
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i]; i++
                val r = power()
                v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, power()) }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalStateException()
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalStateException()
            return s.substring(st, i).toDouble()
        }
    }
}

object Engines {
    val names = listOf("Google", "DuckDuckGo", "Bing", "YouTube")
    private val urls = listOf(
        "https://www.google.com/search?q=", "https://duckduckgo.com/?q=",
        "https://www.bing.com/search?q=", "https://www.youtube.com/results?search_query=")
    fun url(q: String) = urls[Prefs.searchEngine.coerceIn(0, urls.size - 1)] + android.net.Uri.encode(q)
    fun name() = names[Prefs.searchEngine.coerceIn(0, names.size - 1)]
}
