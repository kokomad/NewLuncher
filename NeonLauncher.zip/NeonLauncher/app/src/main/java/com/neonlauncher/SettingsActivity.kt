package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        window.statusBarColor = 0xFF0B0B14.toInt(); window.navigationBarColor = 0xFF0B0B14.toInt()
        val sv = ScrollView(this).apply { setBackgroundColor(0xFF0B0B14.toInt()) }
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(32)) }
        sv.addView(col); setContentView(sv)
        build()
    }

    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun section(t: String) = col.addView(tv(t, 16f, Prefs.accent).apply {
        setPadding(0, dp(24), 0, dp(8)); typeface = Typeface.DEFAULT_BOLD
    })
    private fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); background = roundBg(0x33FFFFFF, dp(14)); setOnClickListener { f() }
    }, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(6) })
    private fun sw(t: String, v: Boolean, f: (Boolean) -> Unit) = col.addView(Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = v; setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> f(c) }
    })
    private fun seek(t: String, min: Int, max: Int, v: Int, unit: String, f: (Int) -> Unit) {
        val label = tv("$t: $v$unit", 14f)
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            progressTintList = ColorStateList.valueOf(Prefs.accent); thumbTintList = ColorStateList.valueOf(Prefs.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p + min); label.text = "$t: ${p + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(label, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }); col.addView(sb)
    }

    private fun build() {
        col.removeAllViews()
        col.addView(tv("⚙ نيون لانشر", 26f).apply { typeface = Typeface.DEFAULT_BOLD })
        col.addView(tv("خصّص شكل الأيقونات والخلفيات بالكامل", 13f, 0x99FFFFFF.toInt()))

        section("🖼 الخلفية")
        val prev = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(Util.decode(this@SettingsActivity, Prefs.wallpaper, 400))
            setOnClickListener { Util.pickWallpaper(this@SettingsActivity) { build() } }
        }
        Util.round(prev, dp(18))
        col.addView(prev, LinearLayout.LayoutParams(MATCH, dp(200)))
        btn("تغيير الخلفية (${Util.WP_COUNT} خلفية)") { Util.pickWallpaper(this) { build() } }
        btn("تعيين كخلفية للنظام") { Util.setSystemWallpaper(this) }
        seek("تعتيم الخلفية", 0, 80, Prefs.dim, "%") { Prefs.dim = it }

        section("🔷 شكل الأيقونات")
        val hs = HorizontalScrollView(this); val row = LinearLayout(this); hs.addView(row)
        val sample = packageManager.getApplicationIcon(packageName)
        for (i in IconShaper.names.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
                background = roundBg(if (Prefs.shape == i) 0x44FFFFFF else 0x11FFFFFF, dp(16))
                setOnClickListener { Prefs.shape = i; build() }
            }
            cell.addView(ImageView(this).apply { setImageBitmap(IconShaper.render(sample, dp(56), i, Prefs.accent, Prefs.glow)) }, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(tv(IconShaper.names[i], 11f))
            row.addView(cell, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        col.addView(hs)

        section("🎨 لون التمييز والتوهج")
        val cr = LinearLayout(this)
        listOf(0xFFFF2DF5, 0xFF00B7FF, 0xFFFF1744, 0xFF00E676, 0xFF9B5CFF, 0xFFFFB300, 0xFFFFFFFF).forEach { cl ->
            val c = cl.toInt()
            val v = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); if (Prefs.accent == c) setStroke(dp(3), Color.WHITE) }
                setOnClickListener { Prefs.accent = c; build() }
            }
            cr.addView(v, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        col.addView(HorizontalScrollView(this).apply { addView(cr) })
        sw("توهج نيون حول الأيقونات", Prefs.glow) { Prefs.glow = it; build() }

        section("📐 الحجم والتخطيط")
        seek("حجم الأيقونة", 40, 80, Prefs.iconSize, "dp") { Prefs.iconSize = it }
        seek("عدد الأعمدة", 3, 6, Prefs.columns, "") { Prefs.columns = it }
        seek("شفافية قائمة التطبيقات", 30, 100, Prefs.drawerAlpha, "%") { Prefs.drawerAlpha = it }
        sw("إظهار أسماء التطبيقات", Prefs.labels) { Prefs.labels = it }
        sw("نظام الساعة 24", Prefs.clock24) { Prefs.clock24 = it }

        section("📱 التطبيقات")
        btn("🙈 إدارة التطبيقات المخفية") { hiddenDialog() }
        btn("مسح التطبيقات المثبتة والدوك") {
            Prefs.setList("pins", emptyList()); Prefs.setList("dock", emptyList()); toast("تم المسح")
        }

        section("🏠 النظام")
        btn("تعيين كلانشر افتراضي") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        btn("↺ إعادة ضبط كل الإعدادات") { Prefs.sp.edit().clear().apply(); build(); toast("تمت إعادة الضبط") }
        col.addView(tv("\nتلميح: اسحب للأعلى لفتح قائمة التطبيقات، للأسفل للإشعارات، واضغط مطولاً على الشاشة للخيارات.", 12f, 0x88FFFFFF.toInt()))
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun hiddenDialog() {
        val apps = Apps.load(this); val hidden = Prefs.list("hidden").toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in hidden }
        AlertDialog.Builder(this).setTitle("التطبيقات المخفية")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c ->
                if (c) hidden.add(apps[i].pkg) else hidden.remove(apps[i].pkg)
            }
            .setPositiveButton("حفظ") { _, _ -> Prefs.setList("hidden", hidden.toList()) }
            .setNegativeButton("إلغاء", null).show()
    }
}
