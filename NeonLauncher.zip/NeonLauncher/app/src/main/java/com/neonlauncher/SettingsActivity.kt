package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var col: LinearLayout
    private var card: LinearLayout? = null
    private val ac get() = Prefs.accent
    private fun a(alpha: Int) = (ac and 0x00FFFFFF) or (alpha shl 24)

    private class Preset(val name: String, val accent: Int, val wp: Int, val shape: Int, val tile: Int)
    private val presets = listOf(
        Preset("💗 نيون ماجنتا", 0xFFFF2DF5.toInt(), 8, 2, 1),
        Preset("💎 سايبر أزرق", 0xFF00B7FF.toInt(), 5, 1, 1),
        Preset("🔥 أحمر ناري", 0xFFFF1744.toInt(), 2, 3, 1),
        Preset("🟢 ماتريكس", 0xFF00E676.toInt(), 16, 0, 0),
        Preset("🔮 أرجواني", 0xFF9B5CFF.toInt(), 0, 5, 1),
        Preset("🌅 غروب", 0xFFFFB300.toInt(), 3, 4, 2)
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val old = Prefs.sp.getString("crash", null)
        if (old != null) { showCrash(old); return }
        try { setup() } catch (t: Throwable) { showCrash(trace(t)) }
    }

    private fun setup() {
        window.statusBarColor = 0xFF08080F.toInt(); window.navigationBarColor = 0xFF08080F.toInt()
        val sv = ScrollView(this).apply { setBackgroundColor(0xFF08080F.toInt()); isVerticalScrollBarEnabled = false }
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(40)) }
        sv.addView(col); setContentView(sv)
        build()
    }

    override fun onResume() { super.onResume(); if (::col.isInitialized) try { build() } catch (t: Throwable) {} }
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data); Util.onGalleryResult(this, req, res, data)
    }

    // ---------- helpers ----------
    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun put(v: View, p: LinearLayout.LayoutParams? = null) { val t = card ?: col; if (p == null) t.addView(v) else t.addView(v, p) }

    private fun card(title: String) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(16))
            background = GradientDrawable().apply { setColor(0xFF12121C.toInt()); cornerRadius = dp(22).toFloat(); setStroke(dp(1), a(0x55)) }
        }
        col.addView(c, lp(MATCH, WRAP).apply { topMargin = dp(14) }); card = c
        if (title.isNotEmpty()) put(tv(title, 16f, ac).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(6)) })
    }

    private fun neon(t: String, f: () -> Unit) = put(Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ac, 0xFF5B4BFF.toInt())).apply { cornerRadius = dp(16).toFloat() }
        setOnClickListener { f() }
    }, lp(MATCH, dp(50)).apply { topMargin = dp(8) })

    private fun ghost(t: String, f: () -> Unit) = put(Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(0x14FFFFFF); cornerRadius = dp(16).toFloat(); setStroke(dp(1), a(0x88)) }
        setOnClickListener { f() }
    }, lp(MATCH, dp(48)).apply { topMargin = dp(8) })

    private fun chips(items: List<String>, sel: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        items.forEachIndexed { i, t ->
            row.addView(tv(t, 13f).apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(if (i == sel) a(0x55) else 0x14FFFFFF)
                    setStroke(dp(1), if (i == sel) ac else 0x22FFFFFF)
                }
                setOnClickListener { onPick(i) }
            }, lp(WRAP, WRAP).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        put(HorizontalScrollView(this).apply { addView(row); isHorizontalScrollBarEnabled = false })
    }

    private fun sw(t: String, v: Boolean, f: (Boolean) -> Unit) = put(Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = v; setPadding(0, dp(8), 0, dp(8))
        thumbTintList = ColorStateList.valueOf(ac); trackTintList = ColorStateList.valueOf(a(0x66))
        setOnCheckedChangeListener { _, c -> f(c) }
    })

    private fun seek(t: String, min: Int, max: Int, v: Int, unit: String, f: (Int) -> Unit) {
        val label = tv("$t: $v$unit", 14f)
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            progressTintList = ColorStateList.valueOf(ac); thumbTintList = ColorStateList.valueOf(ac)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p + min); label.text = "$t: ${p + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        put(label, lp(MATCH, WRAP).apply { topMargin = dp(10) }); put(sb)
    }

    private fun isDefault(): Boolean {
        val ri = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- screen ----------
    private fun build() {
        col.removeAllViews(); card = null
        col.addView(tv("نيون لانشر", 32f).apply { typeface = Typeface.DEFAULT_BOLD; setShadowLayer(24f, 0f, 0f, ac) })
        col.addView(tv("خصّص أيقونات وخلفيات جوالك بأسلوب النيون", 13f, 0x99FFFFFF.toInt()))

        if (intent.getBooleanExtra("welcome", false)) {
            card("👋 أهلاً بك")
            put(tv("١) اختر ثيماً جاهزاً أو خلفيتك من المعرض\n٢) عدّل شكل الأيقونات والألوان\n٣) عيّن اللانشر كافتراضي من الزر أدناه", 13f, 0xCCFFFFFF.toInt()))
        }
        if (!isDefault()) {
            card("⚡ خطوة أخيرة")
            put(tv("اللانشر غير مفعّل كشاشة رئيسية بعد.", 13f, 0xCCFFFFFF.toInt()))
            neon("تعيين كلانشر افتراضي") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        }

        card("✨ ثيمات جاهزة")
        chips(presets.map { it.name }, -1) { i ->
            val p = presets[i]
            Prefs.accent = p.accent; Prefs.wallpaper = p.wp; Prefs.shape = p.shape; Prefs.tile = p.tile; Prefs.glow = true
            build()
        }

        card("🖼 الخلفية")
        val prev = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageBitmap(Util.decode(this@SettingsActivity, Prefs.wallpaper, 400))
            setOnClickListener { Util.pickWallpaper(this@SettingsActivity) { build() } }
        }
        Util.round(prev, dp(18))
        put(prev, lp(MATCH, dp(200)))
        neon("📷 اختيار صورة من المعرض") { Util.pickFromGallery(this) { build() } }
        ghost("الخلفيات الجاهزة (${Util.WP_COUNT})") { Util.pickWallpaper(this) { build() } }
        ghost("تعيين كخلفية للنظام") { Util.setSystemWallpaper(this) }
        seek("تعتيم الخلفية", 0, 80, Prefs.dim, "%") { Prefs.dim = it }

        card("🔷 شكل الأيقونات")
        val hs = HorizontalScrollView(this); val row = LinearLayout(this); hs.addView(row); hs.isHorizontalScrollBarEnabled = false
        val sample = packageManager.getApplicationIcon(packageName)
        for (i in IconShaper.names.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(if (Prefs.shape == i) a(0x44) else 0x11FFFFFF)
                    if (Prefs.shape == i) setStroke(dp(1), ac)
                }
                setOnClickListener { Prefs.shape = i; build() }
            }
            cell.addView(ImageView(this).apply { setImageBitmap(IconShaper.render(sample, dp(56), i, Prefs.accent, Prefs.glow, Prefs.tile)) }, lp(dp(56), dp(56)))
            cell.addView(tv(IconShaper.names[i], 11f))
            row.addView(cell, lp(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        put(hs)
        put(tv("خلفية الأيقونة", 14f).apply { setPadding(0, dp(12), 0, 0) })
        chips(listOf("داكنة", "متدرجة نيون", "زجاجية"), Prefs.tile) { Prefs.tile = it; build() }

        card("🎨 اللون والتوهج")
        val cr = LinearLayout(this)
        listOf(0xFFFF2DF5, 0xFF00B7FF, 0xFFFF1744, 0xFF00E676, 0xFF9B5CFF, 0xFFFFB300, 0xFFFFFFFF).forEach { cl ->
            val c = cl.toInt()
            cr.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); if (Prefs.accent == c) setStroke(dp(3), Color.WHITE) }
                setOnClickListener { Prefs.accent = c; build() }
            }, lp(dp(40), dp(40)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        put(HorizontalScrollView(this).apply { addView(cr); isHorizontalScrollBarEnabled = false })
        sw("توهج نيون حول الأيقونات", Prefs.glow) { Prefs.glow = it; build() }

        card("📐 الحجم والتخطيط")
        seek("حجم الأيقونة", 40, 80, Prefs.iconSize, "dp") { Prefs.iconSize = it }
        seek("عدد الأعمدة", 3, 6, Prefs.columns, "") { Prefs.columns = it }
        seek("شفافية قائمة التطبيقات", 30, 100, Prefs.drawerAlpha, "%") { Prefs.drawerAlpha = it }
        sw("إظهار أسماء التطبيقات", Prefs.labels) { Prefs.labels = it }
        sw("نظام الساعة 24", Prefs.clock24) { Prefs.clock24 = it }

        card("📱 التطبيقات والنظام")
        ghost("🙈 إدارة التطبيقات المخفية") { hiddenDialog() }
        ghost("مسح التطبيقات المثبتة والدوك") { Prefs.setList("pins", emptyList()); Prefs.setList("dock", emptyList()); toast("تم المسح") }
        ghost("↺ إعادة ضبط كل الإعدادات") {
            Prefs.sp.edit().clear().putBoolean("first_done", true).apply(); build(); toast("تمت إعادة الضبط")
        }
        put(tv("\nاسحب للأعلى لفتح التطبيقات • للأسفل للإشعارات • اضغط مطولاً على الشاشة للخيارات", 12f, 0x88FFFFFF.toInt()))
        card = null
    }

    private fun hiddenDialog() {
        val apps = Apps.load(this); val hidden = Prefs.list("hidden").toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in hidden }
        AlertDialog.Builder(this).setTitle("التطبيقات المخفية")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c ->
                if (c) hidden.add(apps[i].pkg) else hidden.remove(apps[i].pkg)
            }
            .setPositiveButton("حفظ") { _, _ -> Prefs.setList("hidden", hidden.toList()) }
            .setNegativeButton("إلغاء", null).show()
    }
}
