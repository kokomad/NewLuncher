package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var col: LinearLayout
    private var card: LinearLayout? = null
    private val ac get() = Prefs.accent
    private fun a(alpha: Int) = (ac and 0x00FFFFFF) or (alpha shl 24)

    private class Preset(val name: String, val accent: Int, val bgMode: Int, val wp: Int, val shape: Int, val tile: Int)
    private val presets = listOf(
        Preset("🔥 برتقالي نيون", 0xFFFF8A00.toInt(), 0, 0, 2, 4),
        Preset("💗 ماجنتا", 0xFFFF2DF5.toInt(), 0, 8, 2, 4),
        Preset("💎 سايبر أزرق", 0xFF00B7FF.toInt(), 0, 5, 1, 4),
        Preset("🟢 ماتريكس", 0xFF00E676.toInt(), 0, 16, 0, 4),
        Preset("🔮 أرجواني", 0xFF9B5CFF.toInt(), 0, 0, 5, 4),
        Preset("🔴 أحمر ناري", 0xFFFF1744.toInt(), 0, 2, 3, 4),
        Preset("🖼 خلفية صورة", 0xFFFF2DF5.toInt(), 1, 8, 2, 1),
        Preset("🌅 غروب", 0xFFFFB300.toInt(), 1, 3, 4, 2)
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val old = Prefs.sp.getString("crash", null)
        if (old != null) { showCrash(old); return }
        try { setup() } catch (t: Throwable) { showCrash(trace(t)) }
    }

    private fun setup() {
        window.statusBarColor = 0xFF08080F.toInt(); window.navigationBarColor = 0xFF08080F.toInt()
        val sv = ScrollView(this).apply { setBackgroundColor(0xFF08080F.toInt()); isVerticalScrollBarEnabled = false }
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(40)) }
        sv.addView(col); setContentView(sv)
        build()
    }

    override fun onResume() { super.onResume(); if (::col.isInitialized) try { build() } catch (t: Throwable) {} }
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data); Util.onGalleryResult(this, req, res, data)
    }

    // ---------- helpers ----------
    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun put(v: View, p: LinearLayout.LayoutParams? = null) { val t = card ?: col; if (p == null) t.addView(v) else t.addView(v, p) }

    private fun card(title: String) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF17171B.toInt(), 0xFF0E0E11.toInt()))
                .apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), a(0x55)) }
        }
        col.addView(c, lp(MATCH, WRAP).apply { topMargin = dp(14) }); card = c
        if (title.isNotEmpty()) put(tv(title, 16f, ac).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(6)) })
    }

    private fun neon(t: String, f: () -> Unit) = put(Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ac, 0xFFB34A00.toInt())).apply { cornerRadius = dp(16).toFloat() }
        setOnClickListener { f() }
    }, lp(MATCH, dp(50)).apply { topMargin = dp(8) })

    private fun ghost(t: String, f: () -> Unit) = put(Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(0x14FFFFFF); cornerRadius = dp(16).toFloat(); setStroke(dp(1), a(0x88)) }
        setOnClickListener { f() }
    }, lp(MATCH, dp(48)).apply { topMargin = dp(8) })

    private fun chips(items: List<String>, sel: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        items.forEachIndexed { i, t ->
            row.addView(tv(t, 13f).apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(if (i == sel) a(0x55) else 0x14FFFFFF)
                    setStroke(dp(1), if (i == sel) ac else 0x22FFFFFF)
                }
                setOnClickListener { onPick(i) }
            }, lp(WRAP, WRAP).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        put(HorizontalScrollView(this).apply { addView(row); isHorizontalScrollBarEnabled = false })
    }

    private fun sw(t: String, v: Boolean, f: (Boolean) -> Unit) = put(Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = v; setPadding(0, dp(8), 0, dp(8))
        thumbTintList = ColorStateList.valueOf(ac); trackTintList = ColorStateList.valueOf(a(0x66))
        setOnCheckedChangeListener { _, c -> f(c) }
    })

    private fun seek(t: String, min: Int, max: Int, v: Int, unit: String, f: (Int) -> Unit) {
        val label = tv("$t: $v$unit", 14f)
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            progressTintList = ColorStateList.valueOf(ac); thumbTintList = ColorStateList.valueOf(ac)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p + min); label.text = "$t: ${p + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        put(label, lp(MATCH, WRAP).apply { topMargin = dp(10) }); put(sb)
    }

    private fun label(t: String) = put(tv(t, 14f).apply { setPadding(0, dp(12), 0, 0) })

    private fun askText(title: String, init: String, multi: Boolean, ok: (String) -> Unit) {
        val et = EditText(this)
        et.setText(init)
        if (multi) et.minLines = 2 else et.setSingleLine()
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("حفظ") { _, _ -> ok(et.text.toString().replace("|", "").trim()) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun isDefault(): Boolean {
        val ri = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun clip() = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    // ---------- screen ----------
    private fun build() {
        col.removeAllViews(); card = null
        col.addView(tv("نيون لانشر", 32f).apply { typeface = Typeface.DEFAULT_BOLD; setShadowLayer(24f, 0f, 0f, ac) })
        col.addView(tv("صمّم شاشتك الرئيسية بأسلوبك", 13f, 0x99FFFFFF.toInt()))

        if (intent.getBooleanExtra("welcome", false)) {
            card("👋 أهلاً بك")
            put(tv("١) اختر ثيماً جاهزاً أو خصّص الألوان\n٢) أدخل اسمك وفعّل الطقس\n٣) عيّن اللانشر كافتراضي من الزر أدناه", 13f, 0xCCFFFFFF.toInt()))
        }
        if (!isDefault()) {
            card("⚡ خطوة أخيرة")
            put(tv("اللانشر غير مفعّل كشاشة رئيسية بعد.", 13f, 0xCCFFFFFF.toInt()))
            neon("تعيين كلانشر افتراضي") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        }

        card("✨ ثيمات جاهزة")
        chips(presets.map { it.name }, -1) { i ->
            val p = presets[i]
            Prefs.accent = p.accent; Prefs.bgMode = p.bgMode; Prefs.wallpaper = p.wp; Prefs.wpVer = Prefs.wpVer + 1
            Prefs.shape = p.shape; Prefs.tile = p.tile; Prefs.glow = true
            if (p.bgMode == 0) Prefs.theme = Themes.CLASSIC
            build()
        }

        card("🎨 تصميم الواجهة (الورقة المقشورة)")
        chips(Themes.names, Prefs.theme) { i ->
            Prefs.theme = i; Prefs.accent = Themes.all[i].accent; Prefs.bgMode = 0; build()
        }
        label("عرض التطبيقات المثبتة")
        chips(listOf("شبكة", "قائمة منحنية"), Prefs.pinStyle) { Prefs.pinStyle = it; build() }
        sw("شريط المعلومات العلوي (التاريخ والطقس والوقت)", Prefs.showPill) { Prefs.showPill = it }
        sw("الزر الدائري العائم لفتح قائمة التطبيقات", Prefs.showFab) { Prefs.showFab = it }

        card("👤 الملف الشخصي والطقس")
        ghost("الاسم: " + Prefs.userName.ifEmpty { "غير محدد (اضغط للتعديل)" }) {
            askText("اسمك", Prefs.userName, false) { Prefs.userName = it; build() }
        }
        sw("عرض الموقع والطقس في البطاقة", Prefs.showWeather) { Prefs.showWeather = it; build() }
        if (Prefs.showWeather) {
            ghost("المدينة: " + Prefs.cityManual.ifEmpty { "تلقائي حسب موقعك" }) {
                askText("اسم المدينة (اتركه فارغاً للموقع التلقائي)", Prefs.cityManual, false) {
                    Prefs.cityManual = it; Prefs.sp.edit().remove("w_temp").apply(); build()
                }
            }
            label("وحدة الحرارة")
            chips(listOf("°C مئوية", "°F فهرنهايت"), if (Prefs.tempF) 1 else 0) { Prefs.tempF = it == 1; build() }
        }

        card("🏠 تصميم الشاشة الرئيسية")
        label("الخلفية")
        chips(listOf("🎨 تصميم الثيم", "🖼 صورة"), Prefs.bgMode) { Prefs.bgMode = it; build() }
        sw("بطاقة الترحيب", Prefs.showCard) { Prefs.showCard = it }
        label("ساعة البطاقة")
        chips(listOf("تناظرية", "رقمية", "مخفية"), Prefs.cardClock) { Prefs.cardClock = it; build() }
        sw("نظام الساعة 24", Prefs.clock24) { Prefs.clock24 = it }
        label("الاقتباس اليومي")
        chips(listOf("يومي تلقائي", "نص مخصص", "إخفاء"), Prefs.quoteMode) { Prefs.quoteMode = it; build() }
        if (Prefs.quoteMode == 1) ghost("✏ تعديل الاقتباس (سطرين)") {
            askText("الاقتباس: السطر الأول ثم سطر جديد للثاني", Prefs.customQuote, true) { Prefs.customQuote = it; build() }
        }
        sw("شريط البحث", Prefs.showSearch) { Prefs.showSearch = it }
        sw("شريط التنقل السفلي", Prefs.showNav) { Prefs.showNav = it }
        sw("الدوك (التطبيقات المفضلة)", Prefs.showDock) { Prefs.showDock = it }
        sw("معلومات البطارية", Prefs.showBattery) { Prefs.showBattery = it }
        sw("إخفاء شريط الحالة", Prefs.hideStatus) { Prefs.hideStatus = it }

        card("🖼 صورة الخلفية")
        val prev = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageBitmap(Util.decode(this@SettingsActivity, Prefs.wallpaper, 400))
            setOnClickListener { Util.pickWallpaper(this@SettingsActivity) { Prefs.bgMode = 1; build() } }
        }
        Util.round(prev, dp(18))
        put(prev, lp(MATCH, dp(180)))
        neon("📷 اختيار صورة من المعرض") { Util.pickFromGallery(this) { Prefs.bgMode = 1; build() } }
        ghost("الخلفيات الجاهزة (${Util.WP_COUNT})") { Util.pickWallpaper(this) { Prefs.bgMode = 1; build() } }
        ghost("تعيين كخلفية للنظام") { Util.setSystemWallpaper(this) }
        seek("تعتيم الصورة", 0, 80, Prefs.dim, "%") { Prefs.dim = it }
        seek("تمويه الخلفية (أندرويد 12+)", 0, 25, Prefs.blur, "") { Prefs.blur = it }
        sw("تغيير الصورة تلقائياً كل يوم", Prefs.autoWp) { Prefs.autoWp = it }

        card("🔷 شكل الأيقونات")
        val hs = HorizontalScrollView(this); val row = LinearLayout(this); hs.addView(row); hs.isHorizontalScrollBarEnabled = false
        val sample = packageManager.getApplicationIcon(packageName)
        for (i in IconShaper.names.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(if (Prefs.shape == i) a(0x44) else 0x11FFFFFF)
                    if (Prefs.shape == i) setStroke(dp(1), ac)
                }
                setOnClickListener { Prefs.shape = i; build() }
            }
            cell.addView(ImageView(this).apply { setImageBitmap(IconShaper.render(sample, dp(56), i, Prefs.accent, Prefs.glow, Prefs.tile, Prefs.themedIcons)) }, lp(dp(56), dp(56)))
            cell.addView(tv(IconShaper.names[i], 11f))
            row.addView(cell, lp(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        put(hs)
        label("خلفية الأيقونة")
        chips(listOf("داكنة", "متدرجة نيون", "زجاجية", "نيومورفيك", "ثلاثي الأبعاد"), Prefs.tile) { Prefs.tile = it; build() }
        sw("توهج نيون حول الأيقونات", Prefs.glow) { Prefs.glow = it; build() }
        sw("أيقونات أحادية اللون (أندرويد 13+ إن دعمها التطبيق)", Prefs.themedIcons) { Prefs.themedIcons = it; build() }

        card("🧊 المؤثرات ثلاثية الأبعاد")
        sw("تفعيل التأثيرات ثلاثية الأبعاد", Prefs.fx3d) { Prefs.fx3d = it; build() }
        sw("صفحات المكعب الدوّار (اسحب يميناً ويساراً)", Prefs.cubePages) { Prefs.cubePages = it }
        if (Prefs.fx3d) {
            sw("بارالاكس عمق بحساس الحركة (إمالة الجوال)", Prefs.parallax) { Prefs.parallax = it }
            sw("ميلان الأيقونات ثلاثي الأبعاد عند اللمس", Prefs.tilt) { Prefs.tilt = it }
            seek("قوة التأثير", 10, 100, Prefs.fxPower, "%") { Prefs.fxPower = it }
            sw("أيقونات OpenGL مجسّمة حقيقية في الدوك", Prefs.glIcons) { Prefs.glIcons = it }
            ghost("🧊 تفعيل أيقونات ثلاثية الأبعاد بعمق وإضاءة") { Prefs.tile = 4; build() }
        }

        card("🎨 لون التمييز")
        val cr = LinearLayout(this)
        listOf(0xFFFF8A00, 0xFFFF2DF5, 0xFF00B7FF, 0xFFFF1744, 0xFF00E676, 0xFF9B5CFF, 0xFFFFD600, 0xFFFFFFFF).forEach { cl ->
            val c = cl.toInt()
            cr.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); if (Prefs.accent == c) setStroke(dp(3), Color.WHITE) }
                setOnClickListener { Prefs.accent = c; build() }
            }, lp(dp(40), dp(40)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        put(HorizontalScrollView(this).apply { addView(cr); isHorizontalScrollBarEnabled = false })
        val hsv = FloatArray(3); Color.colorToHSV(ac, hsv)
        seek("لون مخصص (الطيف)", 0, 360, hsv[0].toInt(), "°") { Prefs.accent = Color.HSVToColor(floatArrayOf(it.toFloat(), 0.95f, 1f)) }
        ghost("تطبيق اللون المخصص وتحديث المعاينة") { build() }

        card("📐 الحجم والتخطيط")
        seek("حجم الأيقونة", 40, 80, Prefs.iconSize, "dp") { Prefs.iconSize = it }
        seek("عدد الأعمدة", 3, 6, Prefs.columns, "") { Prefs.columns = it }
        seek("حجم خط الأسماء", 10, 16, Prefs.labelSize, "sp") { Prefs.labelSize = it }
        sw("إظهار أسماء التطبيقات", Prefs.labels) { Prefs.labels = it }

        card("🧠 قائمة التطبيقات والبحث")
        label("ترتيب التطبيقات")
        chips(listOf("أ - ي", "الأكثر استخداماً", "الأحدث تثبيتاً"), Prefs.sortMode) { Prefs.sortMode = it; build() }
        sw("عرض التطبيقات المقترحة", Prefs.suggest) { Prefs.suggest = it }
        sw("فهرس الحروف الجانبي للتمرير السريع", Prefs.alphaIndex) { Prefs.alphaIndex = it }
        sw("تمويه الخلفية عند فتح القائمة", Prefs.drawerBlur) { Prefs.drawerBlur = it }
        seek("شفافية قائمة التطبيقات", 30, 100, Prefs.drawerAlpha, "%") { Prefs.drawerAlpha = it }
        label("محرك البحث على الويب")
        chips(Engines.names, Prefs.searchEngine) { Prefs.searchEngine = it; build() }
        put(tv("💡 اكتب عملية حسابية مثل 25*4+10 في البحث لتظهر النتيجة فوراً، أو اكتب رابطاً لفتحه مباشرة.", 12f, 0x88FFFFFF.toInt()).apply { setPadding(0, dp(8), 0, 0) })

        card("👆 الإيماءات والاهتزاز")
        label("النقر المزدوج على الشاشة")
        chips(listOf("لا شيء", "فتح القائمة", "الإعدادات", "الإشعارات"), Prefs.doubleTap) { Prefs.doubleTap = it; build() }
        label("السحب للأسفل")
        chips(listOf("الإشعارات", "فتح القائمة", "لا شيء"), Prefs.swipeDown) { Prefs.swipeDown = it; build() }
        sw("اهتزاز خفيف عند اللمس", Prefs.haptics) { Prefs.haptics = it }

        card("💾 نسخ احتياطي")
        ghost("نسخ الإعدادات إلى الحافظة") { clip().setPrimaryClip(ClipData.newPlainText("neon", Util.exportPrefs())); toast("تم النسخ ✓") }
        ghost("مشاركة الإعدادات") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Util.exportPrefs()), "مشاركة الإعدادات"))
        }
        ghost("استيراد الإعدادات من الحافظة") {
            val t = clip().primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            if (Util.importPrefs(t)) { build(); toast("تم الاستيراد ✓") } else toast("لا توجد إعدادات صالحة في الحافظة")
        }

        card("📱 التطبيقات والنظام")
        ghost("🙈 إدارة التطبيقات المخفية") { hiddenDialog() }
        ghost("مسح التطبيقات المثبتة والدوك") { Prefs.setList("pins", emptyList()); Prefs.setList("dock", emptyList()); toast("تم المسح") }
        ghost("↺ إعادة ضبط كل الإعدادات") {
            Prefs.sp.edit().clear().putBoolean("first_done", true).putBoolean("mig2", true).apply(); build(); toast("تمت إعادة الضبط")
        }
        card("👨‍💻 المطور")
        put(tv("khader abo salha", 18f).apply { typeface = Typeface.DEFAULT_BOLD; setShadowLayer(16f, 0f, 0f, ac) })
        put(tv("mankhader@gmail.com", 13f, 0xCCFFFFFF.toInt()).apply { setPadding(0, dp(4), 0, 0); setTextIsSelectable(true) })
        ghost("✉ مراسلة المطور") {
            try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mankhader@gmail.com")).putExtra(Intent.EXTRA_SUBJECT, "نيون لانشر")) }
            catch (e: Exception) { toast("لا يوجد تطبيق بريد") }
        }
        ghost("نسخ البريد الإلكتروني") { clip().setPrimaryClip(ClipData.newPlainText("email", "mankhader@gmail.com")); toast("تم النسخ ✓") }

        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "2.0" }
        put(tv("\nنيون لانشر v$ver — تطوير khader abo salha\nاسحب للأعلى لفتح التطبيقات • للأسفل للإشعارات • اضغط مطولاً على الشاشة للخيارات • اضغط على الاسم في البطاقة لتغييره", 12f, 0x88FFFFFF.toInt()))
        card = null
    }

    private fun hiddenDialog() {
        val apps = Apps.load(this); val hidden = Prefs.list("hidden").toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in hidden }
        AlertDialog.Builder(this).setTitle("التطبيقات المخفية")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c ->
                if (c) hidden.add(apps[i].pkg) else hidden.remove(apps[i].pkg)
            }
            .setPositiveButton("حفظ") { _, _ -> Prefs.setList("hidden", hidden.toList()) }
            .setNegativeButton("إلغاء", null).show()
    }
}
