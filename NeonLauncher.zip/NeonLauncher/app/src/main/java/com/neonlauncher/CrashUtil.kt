package com.neonlauncher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.widget.*
import java.io.PrintWriter
import java.io.StringWriter

fun trace(t: Throwable): String {
    val sw = StringWriter(); t.printStackTrace(PrintWriter(sw)); return sw.toString().take(5000)
}

fun Activity.showCrash(err: String) {
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 60, 24, 24); setBackgroundColor(Color.BLACK) }
    col.addView(TextView(this).apply { text = "⚠ حدث خطأ - صوّر هذه الشاشة وأرسلها"; setTextColor(Color.YELLOW); textSize = 16f })
    col.addView(Button(this).apply {
        text = "نسخ الخطأ"
        setOnClickListener { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("e", err)) }
    })
    col.addView(Button(this).apply {
        text = "مسح الخطأ وإعادة المحاولة"
        setOnClickListener { Prefs.init(this@showCrash); Prefs.sp.edit().remove("crash").commit(); recreate() }
    })
    col.addView(ScrollView(this).apply {
        addView(TextView(this@showCrash).apply { text = err; setTextColor(Color.WHITE); textSize = 11f; setTextIsSelectable(true) })
    })
    setContentView(col)
}
