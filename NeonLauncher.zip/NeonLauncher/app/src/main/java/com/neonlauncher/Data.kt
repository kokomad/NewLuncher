package com.neonlauncher

import java.util.Calendar

object Quotes {
    private val ar = listOf(
        "ركّز على الخير|وأيامٌ أجمل قادمة",
        "ابدأ بخطوة صغيرة|فالطريق يُصنع بالمداومة",
        "اليوم فرصة جديدة|فاجعلها تستحق",
        "الصبر مفتاح الفرج|وكل شيء في وقته",
        "كن أنت التغيير|الذي تريد أن تراه",
        "لا تؤجّل حلمك|فالوقت لا ينتظر",
        "بالهدوء تُحَلّ الأمور|وبالإصرار تتحقق الأهداف",
        "ما تزرعه اليوم|ستحصده غداً",
        "الابتسامة بداية|يوم جميل",
        "اجعل نيّتك صافية|وسعيك مستمراً",
        "العلم نور|والعمل ثمرته",
        "تفاءل بالخير|تجده",
        "قوّتك في استمرارك|لا في سرعتك",
        "اصنع من التحدّي|فرصة للنمو",
        "خطوة اليوم|أفضل من حلم الغد",
        "اختر السلام الداخلي|قبل أي شيء",
        "الأفكار الجميلة|تصنع أياماً جميلة",
        "لا تقارن نفسك بغيرك|قارنها بما كنت عليه",
        "الإتقان عادة|وليس صدفة",
        "من جدّ وجد|ومن زرع حصد"
    )
    private val en = listOf(
        "Focus on the good.|Better times are ahead.",
        "Start small.|Consistency builds the road.",
        "Today is a fresh chance.|Make it count.",
        "Be the change|you wish to see.",
        "Don't wait for tomorrow.|Begin today.",
        "Progress, not perfection.|Keep moving.",
        "What you plant today|you harvest tomorrow.",
        "Stay curious.|Stay kind.",
        "Calm mind.|Clear goals.",
        "Small steps every day|lead to big results."
    )

    /** يعيد (السطر الأول، السطر الثاني) */
    fun current(): Pair<String, String> {
        if (Prefs.quoteMode == 1 && Prefs.customQuote.isNotBlank()) {
            val parts = Prefs.customQuote.split("\n", limit = 2)
            return parts[0].trim() to parts.getOrElse(1) { "" }.trim()
        }
        val l = if (isAr()) ar else en
        val d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val idx = ((d + Prefs.quoteOffset) % l.size + l.size) % l.size
        val s = l[idx].split("|")
        return s[0] to s.getOrElse(1) { "" }
    }
}
