package com.neonlauncher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.widget.*

class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val err = intent.getStringExtra("e") ?: "unknown"
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 60, 24, 24); setBackgroundColor(Color.BLACK) }
        col.addView(TextView(this).apply { text = "⚠ حدث خطأ - صوّر هذه الشاشة وأرسلها"; setTextColor(Color.YELLOW); textSize = 16f })
        col.addView(Button(this).apply {
            text = "نسخ الخطأ"
            setOnClickListener { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("e", err)) }
        })
        col.addView(ScrollView(this).apply {
            addView(TextView(this@CrashActivity).apply { text = err; setTextColor(Color.WHITE); textSize = 11f; setTextIsSelectable(true) })
        })
        setContentView(col)
    }
}
