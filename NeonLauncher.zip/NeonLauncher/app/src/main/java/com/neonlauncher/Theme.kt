package com.neonlauncher

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** تعريف ثيم كامل: الخلفية + ألوان البطاقة + ألوان اللوحات */
class ThemeDef(
    val name: String,
    val accent: Int,       // لون التمييز الافتراضي
    val cardTop: Int,      // تدرج البطاقة (أعلى)
    val cardBottom: Int,   // تدرج البطاقة (أسفل)
    val flap: Int,         // لون الزاوية المقشورة
    val ink: Int,          // لون النص الرئيسي على البطاقة
    val sub: Int,          // لون النص الثانوي / التحية
    val panel: Int,        // لون لوحات الزجاج (الأيقونات، الاقتباس، الشريط)
    val drawer: Int        // لون خلفية قائمة التطبيقات
)

object Themes {
    const val CLASSIC = 5
    val all = listOf(
        // 0: برتقال زجاجي (فقاعات زجاجية)
        ThemeDef("🟠 برتقال زجاجي", 0xFFFF8A00.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE3C7.toInt(), 0xFFFFA24D.toInt(),
            0xFF24150A.toInt(), 0xFFE06A00.toInt(), 0xCC2B1608.toInt(), 0xFF1F1006.toInt()),
        // 1: أبيض وأسود (منحنى S)
        ThemeDef("⚫ أبيض وأسود", 0xFFEDEDED.toInt(), 0xFF191D1B.toInt(), 0xFF050706.toInt(), 0xFFDADADA.toInt(),
            0xFFFFFFFF.toInt(), 0xFFBDBDBD.toInt(), 0xCC0A0D0B.toInt(), 0xFF070908.toInt()),
        // 2: ذهبي وأزرق (ورقة مقشورة)
        ThemeDef("🟡 ذهبي وأزرق", 0xFFFFB800.toInt(), 0xFF1030C8.toInt(), 0xFF0A1A7A.toInt(), 0xFFFFC21A.toInt(),
            0xFFFFFFFF.toInt(), 0xFFFFD35A.toInt(), 0xCC0A1450.toInt(), 0xFF050B2E.toInt()),
        // 3: الورقة الزرقاء
        ThemeDef("🔵 الورقة الزرقاء", 0xFF4D7CFF.toInt(), 0xFF0B1436.toInt(), 0xFF030818.toInt(), 0xFF2F5BFF.toInt(),
            0xFFFFFFFF.toInt(), 0xFF8FB0FF.toInt(), 0xCC050B22.toInt(), 0xFF030818.toInt()),
        // 4: المنحنى (تصميم اللانشر المرجعي)
        ThemeDef("🌊 المنحنى الأزرق", 0xFF1E96E8.toInt(), 0xFF1B1B1E.toInt(), 0xFF040404.toInt(), 0xFF2AA7F0.toInt(),
            0xFFFFFFFF.toInt(), 0xFF5DB8F5.toInt(), 0xCC0A0A0B.toInt(), 0xFF08080A.toInt()),
        // 5: نيون الأصلي (الأمواج)
        ThemeDef("⚡ نيون الأصلي", 0xFFFF8A00.toInt(), 0xFF1D1D21.toInt(), 0xFF0C0C0E.toInt(), 0xFFFF8A00.toInt(),
            0xFFFFFFFF.toInt(), 0xFFFF8A00.toInt(), 0xCC0C0C0E.toInt(), 0xFF0A0A0D.toInt())
    )
    val names get() = all.map { it.name }
    fun cur(): ThemeDef = all[Prefs.theme.coerceIn(0, all.size - 1)]
}

/**
 * بطاقة بزاوية مقشورة (مثل الورقة المطوية): جسم بتدرج + ظل ناعم + لمعة + زاوية ملتفة.
 * تُرسم مرة واحدة في Bitmap وتُعاد عند تغيّر الحجم فقط.
 */
class PeelDrawable(
    private val top: Int, private val bottom: Int, private val flap: Int,
    private val radius: Float, private val curl: Float, private val pad: Float
) : Drawable() {
    private var cache: Bitmap? = null
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)

    override fun onBoundsChange(b: Rect) { cache = null }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() < 8 || b.height() < 8) return
        var bm = cache
        if (bm == null || bm.width != b.width() || bm.height != b.height()) { bm = render(b.width(), b.height()); cache = bm }
        c.drawBitmap(bm, b.left.toFloat(), b.top.toFloat(), bp)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    private fun p(f: Paint.() -> Unit) = Paint(Paint.ANTI_ALIAS_FLAG).apply(f)

    private fun render(bw: Int, bh: Int): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val l = pad; val t = pad; val r = bw - pad; val b = bh - pad
        val w = r - l; val h = b - t
        val cu = min(curl, min(w, h) * 0.4f)
        val rad = min(radius, min(w, h) * 0.3f)

        val body = Path()
        body.moveTo(l + rad, t); body.lineTo(r - rad, t); body.quadTo(r, t, r, t + rad)
        body.lineTo(r, b - cu); body.lineTo(r - cu, b); body.lineTo(l + rad, b)
        body.quadTo(l, b, l, b - rad); body.lineTo(l, t + rad); body.quadTo(l, t, l + rad, t); body.close()

        // ظل ناعم
        cv.save(); cv.translate(0f, pad * 0.4f)
        cv.drawPath(body, p { color = 0x99000000.toInt(); maskFilter = BlurMaskFilter(pad * 0.85f, BlurMaskFilter.Blur.NORMAL) })
        cv.restore()

        // الجسم
        cv.drawPath(body, p { shader = LinearGradient(l, t, r, b, top, bottom, Shader.TileMode.CLAMP) })

        // لمعة علوية
        cv.save(); cv.clipPath(body)
        cv.drawOval(RectF(l - w * 0.2f, t - h * 0.6f, r + w * 0.2f, t + h * 0.30f),
            p { shader = LinearGradient(0f, t, 0f, t + h * 0.30f, 0x2EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP) })
        cv.restore()

        // إطار رقيق
        cv.drawPath(body, p { style = Paint.Style.STROKE; strokeWidth = 1.3f; color = 0x33FFFFFF })

        // الزاوية المقشورة
        val fp = Path()
        fp.moveTo(r, b - cu)
        fp.cubicTo(r - cu * 0.25f, b - cu * 0.97f, r - cu * 0.80f, b - cu * 0.88f, r - cu * 0.84f, b - cu * 0.84f)
        fp.cubicTo(r - cu * 0.88f, b - cu * 0.80f, r - cu * 0.97f, b - cu * 0.25f, r - cu, b)
        fp.close()

        // ظل الزاوية على الجسم
        cv.save(); cv.clipPath(body); cv.translate(-cu * 0.10f, -cu * 0.10f)
        cv.drawPath(fp, p { color = 0xAA000000.toInt(); maskFilter = BlurMaskFilter(cu * 0.14f, BlurMaskFilter.Blur.NORMAL) })
        cv.restore()

        val light = blend(flap, Color.WHITE, 0.35f)
        val dark = blend(flap, Color.BLACK, 0.25f)
        cv.drawPath(fp, p { shader = LinearGradient(r - cu * 0.5f, b - cu * 0.5f, r - cu * 0.85f, b - cu * 0.85f, dark, light, Shader.TileMode.CLAMP) })
        cv.drawPath(fp, p { style = Paint.Style.STROKE; strokeWidth = 1.1f; color = 0x66FFFFFF })
        return bmp
    }

    private fun blend(a: Int, b: Int, k: Float): Int {
        val ik = 1f - k
        return Color.argb(255,
            (Color.red(a) * ik + Color.red(b) * k).toInt(),
            (Color.green(a) * ik + Color.green(b) * k).toInt(),
            (Color.blue(a) * ik + Color.blue(b) * k).toInt())
    }
}

/** زر دائري عائم (قرص أبيض لامع + قوس ملوّن + عقارب) لفتح قائمة التطبيقات */
class DialFabView(c: Context) : View(c) {
    var accent: Int = DEFAULT_ACCENT
        set(v) { field = v; invalidate() }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = min(w, h) / 2f
        if (r <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        // هالة
        ap.color = 0x77FFFFFF; ap.maskFilter = BlurMaskFilter(r * 0.22f, BlurMaskFilter.Blur.NORMAL)
        cv.drawCircle(cx, cy, r * 0.86f, ap); ap.maskFilter = null
        // القرص
        ap.shader = RadialGradient(cx - r * 0.25f, cy - r * 0.3f, r, intArrayOf(0xFFFFFFFF.toInt(), 0xFFE4E7EE.toInt()),
            floatArrayOf(0.2f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 0.78f, ap); ap.shader = null
        // القوس
        ap.style = Paint.Style.STROKE; ap.strokeWidth = r * 0.12f; ap.strokeCap = Paint.Cap.ROUND; ap.color = accent
        cv.drawArc(RectF(cx - r * 0.56f, cy - r * 0.56f, cx + r * 0.56f, cy + r * 0.56f), -100f, 112f, false, ap)
        // العقارب
        val cal = Calendar.getInstance()
        val mn = cal.get(Calendar.MINUTE); val hr = cal.get(Calendar.HOUR) + mn / 60.0
        ap.color = 0xFF2A2F3A.toInt()
        fun hand(deg: Double, len: Float, wd: Float) {
            val a = Math.toRadians(deg)
            ap.strokeWidth = wd
            cv.drawLine(cx, cy, cx + (len * sin(a)).toFloat(), cy - (len * cos(a)).toFloat(), ap)
        }
        hand(hr * 30.0, r * 0.28f, r * 0.07f)
        hand(mn * 6.0, r * 0.42f, r * 0.05f)
        ap.style = Paint.Style.FILL; ap.color = accent
        cv.drawCircle(cx, cy, r * 0.06f, ap)
    }
}
