package com.neonlauncher

import android.app.Application
import android.os.Process
import kotlin.system.exitProcess

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { getSharedPreferences("neon", 0).edit().putString("crash", trace(e)).commit() } catch (x: Throwable) {}
            Process.killProcess(Process.myPid()); exitProcess(1)
        }
    }
}
