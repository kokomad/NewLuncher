package com.neonlauncher

import android.app.Application
import android.content.Intent
import android.os.Process
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
                startActivity(Intent(this, CrashActivity::class.java).putExtra("e", sw.toString().take(5000))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                Thread.sleep(600)
            } catch (x: Throwable) {}
            Process.killProcess(Process.myPid()); exitProcess(1)
        }
    }
}
