package com.neonlauncher

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class WeatherInfo(val city: String, val tempC: Float, val code: Int, val isDay: Boolean)

/** الطقس عبر Open-Meteo (مجاني وبدون مفتاح) + الموقع من النظام أو مدينة يدوية */
object Weather {
    @Volatile private var busy = false

    fun cached(): WeatherInfo? {
        val sp = Prefs.sp
        if (!sp.contains("w_temp")) return null
        return WeatherInfo(sp.getString("w_city", "") ?: "", sp.getFloat("w_temp", 0f), sp.getInt("w_code", 0), sp.getBoolean("w_day", true))
    }

    fun isFresh(): Boolean {
        val sp = Prefs.sp
        val age = System.currentTimeMillis() - sp.getLong("w_time", 0L)
        return cached() != null && age < 30 * 60 * 1000L && (sp.getString("w_src", "") ?: "") == Prefs.cityManual
    }

    fun hasPerm(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun desc(code: Int, day: Boolean): String {
        val ar = isAr()
        return when (code) {
            0 -> if (ar) (if (day) "صافٍ" else "سماء صافية") else (if (day) "Clear" else "Clear night")
            1, 2 -> if (ar) "غائم جزئياً" else "Partly cloudy"
            3 -> if (ar) "غائم" else "Cloudy"
            45, 48 -> if (ar) "ضباب" else "Fog"
            in 51..57 -> if (ar) "رذاذ" else "Drizzle"
            in 61..67 -> if (ar) "مطر" else "Rain"
            in 71..77, 85, 86 -> if (ar) "ثلوج" else "Snow"
            in 80..82 -> if (ar) "زخات مطر" else "Showers"
            in 95..99 -> if (ar) "عاصفة رعدية" else "Thunderstorm"
            else -> if (ar) "—" else "—"
        }
    }

    fun glyph(code: Int, day: Boolean): Int = when (code) {
        0 -> if (day) GlyphView.SUN else GlyphView.MOON
        1, 2, 3, 45, 48 -> GlyphView.CLOUD
        in 51..67, in 80..82 -> GlyphView.RAIN
        in 71..77, 85, 86 -> GlyphView.SNOW
        in 95..99 -> GlyphView.STORM
        else -> GlyphView.CLOUD
    }

    private fun get(u: String): String {
        val cn = URL(u).openConnection() as HttpURLConnection
        cn.connectTimeout = 8000; cn.readTimeout = 8000
        try { return cn.inputStream.bufferedReader().use { it.readText() } } finally { cn.disconnect() }
    }

    @SuppressLint("MissingPermission")
    private fun lastLoc(c: Context): Location? {
        if (!hasPerm(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: Throwable) {}
        }
        return best
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun singleUpdate(c: Context, after: () -> Unit) {
        try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val prov = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
            else if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER
            else return
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(l: Location) {
                    Prefs.sp.edit().putString("w_lat", l.latitude.toString()).putString("w_lon", l.longitude.toString()).apply()
                    after()
                }
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }, Looper.getMainLooper())
        } catch (e: Throwable) {}
    }

    @Suppress("DEPRECATION")
    private fun cityName(c: Context, lat: Double, lon: Double): String {
        try {
            if (Geocoder.isPresent()) {
                val l = Geocoder(c, Locale.getDefault()).getFromLocation(lat, lon, 1)
                if (l != null && l.isNotEmpty()) {
                    val a = l[0]
                    val n = a.locality ?: a.subAdminArea ?: a.adminArea
                    if (n != null) return if (a.countryName != null) "$n، ${a.countryName}" else n
                }
            }
        } catch (e: Throwable) {}
        try {
            val j = JSONObject(get("https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=${Locale.getDefault().language}"))
            val n = j.optString("city").ifEmpty { j.optString("locality") }
            val cn = j.optString("countryName")
            if (n.isNotEmpty()) return if (cn.isNotEmpty()) "$n، $cn" else n
        } catch (e: Throwable) {}
        return ""
    }

    /** يُستدعى من أي خيط؛ done يُنفَّذ على خيط الخلفية */
    fun refresh(c: Context, done: () -> Unit) {
        if (busy) return
        busy = true
        val app = c.applicationContext
        Thread {
            try {
                val manual = Prefs.cityManual
                var lat = Double.NaN; var lon = Double.NaN; var city = ""
                if (manual.isNotEmpty()) {
                    val j = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=${Locale.getDefault().language}&name=" + android.net.Uri.encode(manual)))
                    val r = j.optJSONArray("results")
                    if (r != null && r.length() > 0) {
                        val o = r.getJSONObject(0)
                        lat = o.getDouble("latitude"); lon = o.getDouble("longitude")
                        val cn = o.optString("country")
                        city = if (cn.isNotEmpty()) o.optString("name", manual) + "، " + cn else o.optString("name", manual)
                    }
                } else {
                    val l = lastLoc(app)
                    if (l != null) {
                        lat = l.latitude; lon = l.longitude
                        Prefs.sp.edit().putString("w_lat", lat.toString()).putString("w_lon", lon.toString()).apply()
                    } else {
                        val sl = Prefs.sp.getString("w_lat", null)?.toDoubleOrNull()
                        val sn = Prefs.sp.getString("w_lon", null)?.toDoubleOrNull()
                        if (sl != null && sn != null) { lat = sl; lon = sn }
                        else if (hasPerm(app)) {
                            android.os.Handler(Looper.getMainLooper()).post {
                                singleUpdate(app) { busy = false; refresh(app, done) }
                            }
                        }
                    }
                    if (!lat.isNaN()) city = cityName(app, lat, lon)
                }
                if (!lat.isNaN() && !lon.isNaN()) {
                    val j = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,is_day&timezone=auto"))
                    val cur = j.getJSONObject("current")
                    Prefs.sp.edit()
                        .putString("w_city", city)
                        .putFloat("w_temp", cur.getDouble("temperature_2m").toFloat())
                        .putInt("w_code", cur.getInt("weather_code"))
                        .putBoolean("w_day", cur.optInt("is_day", 1) == 1)
                        .putLong("w_time", System.currentTimeMillis())
                        .putString("w_src", manual)
                        .apply()
                    done()
                }
            } catch (e: Throwable) {
            } finally { busy = false }
        }.start()
    }
}
