package com.neonlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.tan

/**
 * دوك بأيقونات ثلاثية الأبعاد حقيقية (OpenGL ES 2.0):
 * كل أيقونة مجسّم مبثوق بسمك ومنظور، يدور بحساس الحركة وعند اللمس.
 */
class Dock3DView(c: Context) : GLSurfaceView(c) {
    var onTap: ((Int) -> Unit)? = null
    var onLong: ((Int) -> Unit)? = null
    private var count = 0
    private var iconPx = 0
    private var topPx = 0
    private val r = R()
    private val gd: GestureDetector

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setZOrderOnTop(true)
        setRenderer(r)
        renderMode = RENDERMODE_WHEN_DIRTY
        gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val i = indexAt(e.x); if (i >= 0) onTap?.invoke(i); return true
            }
            override fun onLongPress(e: MotionEvent) {
                val i = indexAt(e.x)
                if (i >= 0) { performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); onLong?.invoke(i) }
            }
        })
    }

    private fun indexAt(x: Float): Int {
        if (count <= 0 || width <= 0) return -1
        return (x / (width.toFloat() / count)).toInt().coerceIn(0, count - 1)
    }

    /** icons: صور الوجه، iconPx: حجم الأيقونة بالبكسل، topPx: مركز الأيقونة من أعلى العرض */
    fun setIcons(icons: List<Bitmap>, iconPx: Int, centerYPx: Int, accent: Int) {
        count = icons.size; this.iconPx = iconPx; topPx = centerYPx
        synchronized(r) { r.pending = ArrayList(icons); r.size = iconPx; r.cy = centerYPx; r.accent = accent }
        requestRender()
    }

    fun tilt(nx: Float, ny: Float) { r.tx = nx; r.ty = ny; requestRender() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val i = indexAt(e.x)
                if (count > 0 && width > 0) {
                    val cw = width.toFloat() / count
                    r.pnx = (((e.x - i * cw) / cw - 0.5f) * 2f).coerceIn(-1f, 1f)
                    r.pny = ((e.y - topPx) / (iconPx / 2f).coerceAtLeast(1f)).coerceIn(-1f, 1f)
                    r.press = i
                }
                requestRender()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { r.press = -1; requestRender() }
        }
        return true
    }

    private inner class R : Renderer {
        @Volatile var tx = 0f
        @Volatile var ty = 0f
        @Volatile var press = -1
        @Volatile var pnx = 0f
        @Volatile var pny = 0f
        @Volatile var size = 0
        @Volatile var cy = 0
        @Volatile var accent = Color.rgb(255, 138, 0)
        var pending: List<Bitmap>? = null

        private var cur: List<Bitmap> = emptyList()
        private var tex = IntArray(0)
        private var rotX = FloatArray(0)
        private var rotY = FloatArray(0)
        private var sc = FloatArray(0)
        private var prog = 0
        private var aPos = 0; private var aUv = 0; private var uMvp = 0; private var uTex = 0; private var uTint = 0
        private var w = 1; private var h = 1
        private val proj = FloatArray(16); private val view = FloatArray(16)
        private val model = FloatArray(16); private val mv = FloatArray(16); private val mvp = FloatArray(16)
        private val vb = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-0.5f, -0.5f, 0f, 1f, 0.5f, -0.5f, 1f, 1f, -0.5f, 0.5f, 0f, 0f, 0.5f, 0.5f, 1f, 0f)); position(0)
        }
        private var needTex = false

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type); GLES20.glShaderSource(s, src); GLES20.glCompileShader(s); return s
        }

        override fun onSurfaceCreated(gl: GL10?, cfg: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            val vs = "attribute vec4 aPos; attribute vec2 aUv; uniform mat4 uMvp; varying vec2 vUv;" +
                "void main(){ gl_Position = uMvp * aPos; vUv = aUv; }"
            val fs = "precision mediump float; varying vec2 vUv; uniform sampler2D uTex; uniform vec4 uTint;" +
                "void main(){ gl_FragColor = texture2D(uTex, vUv) * uTint; }"
            prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(prog)
            aPos = GLES20.glGetAttribLocation(prog, "aPos"); aUv = GLES20.glGetAttribLocation(prog, "aUv")
            uMvp = GLES20.glGetUniformLocation(prog, "uMvp"); uTex = GLES20.glGetUniformLocation(prog, "uTex")
            uTint = GLES20.glGetUniformLocation(prog, "uTint")
            tex = IntArray(0); needTex = cur.isNotEmpty()   // السياق أُعيد إنشاؤه: ارفع الصور من جديد
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            w = width.coerceAtLeast(1); h = height.coerceAtLeast(1)
            GLES20.glViewport(0, 0, w, h)
            val fov = 40f
            val d = (h / 2f) / tan(Math.toRadians(fov / 2.0)).toFloat()
            Matrix.perspectiveM(proj, 0, fov, w.toFloat() / h, 1f, d * 4f)
            Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        }

        private fun uploadTextures() {
            if (tex.isNotEmpty()) GLES20.glDeleteTextures(tex.size, tex, 0)
            tex = IntArray(cur.size)
            GLES20.glGenTextures(tex.size, tex, 0)
            for (i in cur.indices) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[i])
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, cur[i], 0)
            }
            rotX = FloatArray(cur.size); rotY = FloatArray(cur.size); sc = FloatArray(cur.size) { 1f }
            needTex = false
        }

        private fun drawQuad(texId: Int, tint: FloatArray) {
            Matrix.multiplyMM(mv, 0, view, 0, model, 0)
            Matrix.multiplyMM(mvp, 0, proj, 0, mv, 0)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
            GLES20.glUniform4f(uTint, tint[0], tint[1], tint[2], tint[3])
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
            GLES20.glUniform1i(uTex, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }

        override fun onDrawFrame(gl: GL10?) {
            val p = synchronized(this) { val x = pending; pending = null; x }
            if (p != null) { cur = p; needTex = true }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            if (needTex) uploadTextures()
            if (cur.isEmpty() || tex.size != cur.size) return

            GLES20.glUseProgram(prog)
            GLES20.glEnableVertexAttribArray(aPos); GLES20.glEnableVertexAttribArray(aUv)
            vb.position(0); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, vb)
            vb.position(2); GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 16, vb)

            val n = cur.size
            val cw = w.toFloat() / n
            val s = size * 1.12f
            val depth = s * 0.16f
            val layers = 10
            val ar = Color.red(accent) / 255f; val ag = Color.green(accent) / 255f; val ab = Color.blue(accent) / 255f
            val side = floatArrayOf(0.14f + 0.30f * ar, 0.14f + 0.30f * ag, 0.14f + 0.30f * ab, 1f)
            var moving = false
            for (i in 0 until n) {
                var tRy = tx * 20f; var tRx = -ty * 20f; var tS = 1f
                if (press == i) { tRy += pnx * 22f; tRx += -pny * 22f; tS = 0.93f }
                rotY[i] += (tRy - rotY[i]) * 0.22f; rotX[i] += (tRx - rotX[i]) * 0.22f; sc[i] += (tS - sc[i]) * 0.3f
                if (abs(tRy - rotY[i]) > 0.15f || abs(tRx - rotX[i]) > 0.15f || abs(tS - sc[i]) > 0.003f) moving = true

                // إضاءة: الوجه يسطع عند الميل نحو الضوء (أعلى اليسار)
                val lit = (1f + (-rotY[i] * 0.004f) + (rotX[i] * 0.004f)).coerceIn(0.8f, 1.25f)
                val front = floatArrayOf(lit, lit, lit, 1f)

                val x = (i + 0.5f) * cw - w / 2f
                val y = h / 2f - cy
                for (t in 0..layers) {
                    val z = -depth * (layers - t) / layers
                    Matrix.setIdentityM(model, 0)
                    Matrix.translateM(model, 0, x, y, 0f)
                    Matrix.rotateM(model, 0, rotX[i], 1f, 0f, 0f)
                    Matrix.rotateM(model, 0, rotY[i], 0f, 1f, 0f)
                    Matrix.translateM(model, 0, 0f, 0f, z + depth * 0.5f)
                    Matrix.scaleM(model, 0, s * sc[i], s * sc[i], 1f)
                    drawQuad(tex[i], if (t == layers) front else side)
                }
            }
            GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUv)
            if (moving) requestRender()
        }
    }
}
