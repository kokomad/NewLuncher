package com.neonlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.*
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : Activity() {
    companion object {
        const val REQ_BIND = 7702; const val REQ_CONFIG = 7703; const val REQ_VOICE = 7704; const val REQ_LOC = 7705
    }

    private class HomeItem(val app: AppInfo?, val folder: String?)

    /** سطر معلومات في البطاقة: أيقونة + نص رئيسي + نص ثانوي */
    private inner class InfoRow(kind: Int) {
        val glyph = GlyphView(this@MainActivity, kind)
        val t1 = tv("", 12f)
        val t2 = tv("", 10f)
        val root = LinearLayout(this@MainActivity)
        init {
            root.orientation = LinearLayout.HORIZONTAL; root.gravity = Gravity.CENTER_VERTICAL
            root.addView(glyph, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(10) })
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            t1.maxLines = 1; t2.maxLines = 1
            col.addView(t1); col.addView(t2)
            root.addView(col)
        }
    }

    private lateinit var root: FrameLayout
    private lateinit var bg: WaveBackgroundView
    private lateinit var wp: ImageView
    private lateinit var dim: View
    private lateinit var home: LinearLayout
    private lateinit var homeScroll: ScrollView
    private lateinit var card: LinearLayout
    private lateinit var greetTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var rowDate: InfoRow
    private lateinit var rowTime: InfoRow
    private lateinit var rowLoc: InfoRow
    private lateinit var rowWx: InfoRow
    private lateinit var analog: AnalogClockView
    private lateinit var digital: TextView
    private lateinit var widgetBox: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var dockWrap: FrameLayout
    private lateinit var dock3d: Dock3DView
    private var dockApps = listOf<AppInfo>()
    private var glOn = false
    private lateinit var pinGrid: GridView
    private lateinit var quoteBox: LinearLayout
    private lateinit var quote1: TextView
    private lateinit var quote2: TextView
    private lateinit var quoteL: TextView
    private lateinit var quoteR: TextView
    private lateinit var quoteBar: View
    private lateinit var searchBar: LinearLayout
    private lateinit var searchGlyph: GlyphView
    private lateinit var micGlyph: GlyphView
    private lateinit var navBar: LinearLayout
    private lateinit var homePill: FrameLayout
    private lateinit var navHomeGlyph: GlyphView
    private lateinit var drawer: LinearLayout
    private lateinit var searchBox: LinearLayout
    private lateinit var drawerSearchGlyph: GlyphView
    private lateinit var drawerMic: GlyphView
    private lateinit var calcRow: TextView
    private lateinit var webRow: TextView
    private lateinit var suggestWrap: LinearLayout
    private lateinit var suggestRow: LinearLayout
    private lateinit var suggestTitle: TextView
    private lateinit var drawerGrid: GridView
    private lateinit var indexBar: LinearLayout
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private lateinit var awm: AppWidgetManager
    private lateinit var host: AppWidgetHost
    private lateinit var par: Parallax

    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { if (ready) try { updateCard() } catch (e: Throwable) {}; ui.postDelayed(this, 15000) }
    }
    private var all = listOf<AppInfo>()
    private var sig = ""
    private var wpKey = ""
    private var drawerOpen = false
    private var query = ""
    private var ready = false
    private var hostOn = false
    private var pendingWid = -1
    private var battText = ""
    private var welcomeShown = false
    private var indexTouch = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadApps() }
    }
    private val batRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { if (i != null) updateBattery(i) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val old = Prefs.sp.getString("crash", null)
        if (old != null) { showCrash(old); return }
        try { setup(); ready = true } catch (t: Throwable) { showCrash(trace(t)) }
    }

    /** ترحيل لمرة واحدة إلى التصميم الجديد */
    private fun migrate() {
        if (Prefs.sp.getBoolean("mig2", false)) return
        Prefs.accent = DEFAULT_ACCENT; Prefs.tile = 3; Prefs.shape = 2; Prefs.glow = true
        Prefs.bgMode = 0; Prefs.iconSize = 60; Prefs.columns = 4
        Prefs.sp.edit().putBoolean("mig2", true).apply()
    }

    private fun migrate3() {
        if (Prefs.sp.getBoolean("mig3", false)) return
        Prefs.tile = 4; Prefs.fx3d = true
        Prefs.sp.edit().putBoolean("mig3", true).apply()
    }

    private fun setup() {
        migrate(); migrate3()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF0B0B0D.toInt())
        bg = WaveBackgroundView(this)
        root.addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))
        wp = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wp, FrameLayout.LayoutParams(MATCH, MATCH))
        dim = View(this)
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        buildHome(); buildDrawer()
        val cd = 9000f * resources.displayMetrics.density
        for (v in listOf<View>(card, dockWrap, pinGrid, quoteBox, searchBar, navBar, home, drawer, bg, wp)) v.cameraDistance = cd
        par = Parallax(this) { x, y -> applyParallax(x, y) }
        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop; val bt = ins.systemWindowInsetBottom
            home.setPadding(0, t + dp(8), 0, bt + dp(10))
            drawer.setPadding(dp(8), t + dp(12), dp(8), bt)
            ins
        }
        root.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val hDp = (b - t) / resources.displayMetrics.density
            quoteBox.visibility = if (Prefs.quoteMode != 2 && hDp >= 660) View.VISIBLE else View.GONE
        }
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || indexTouch) return false
                val dy = e2.y - e1.y
                if (abs(dy) < dp(80) || abs(vy) < 800 || abs(dy) < abs(e2.x - e1.x)) return false
                if (drawerOpen) { if (dy > 0 && !drawerGrid.canScrollVertically(-1)) closeDrawer() }
                else if (dy < 0) { if (!homeScroll.canScrollVertically(1)) openDrawer(false) }
                else if (!homeScroll.canScrollVertically(-1)) when (Prefs.swipeDown) { 0 -> expandNotifications(); 1 -> openDrawer(false) }
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (drawerOpen || Prefs.doubleTap == 0) return false
                when (Prefs.doubleTap) {
                    1 -> openDrawer(false)
                    2 -> startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                    3 -> expandNotifications()
                }
                return true
            }
        })
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }
        registerReceiver(rx, f)
        val sticky = registerReceiver(batRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
        loadApps()
        if (!Prefs.sp.getBoolean("first_done", false)) {
            Prefs.sp.edit().putBoolean("first_done", true).apply()
            welcomeShown = true
            startActivity(Intent(this, SettingsActivity::class.java).putExtra("welcome", true))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        try { unregisterReceiver(rx) } catch (e: Exception) {}
        try { unregisterReceiver(batRx) } catch (e: Exception) {}
    }
    override fun onStart() { super.onStart(); if (ready) try { host.startListening(); hostOn = true } catch (e: Throwable) {} }
    override fun onStop() { super.onStop(); if (hostOn) try { host.stopListening() } catch (e: Throwable) {}; hostOn = false }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick); if (ready) { par.stop(); dock3d.onPause() } }
    override fun onResume() {
        super.onResume()
        if (!ready) return
        try {
            dock3d.onResume()
            applyPrefs()
            ui.removeCallbacks(tick); ui.post(tick)
            if (welcomeShown) welcomeShown = false else maybeAskLocation()
            refreshWeather(false)
            if (Prefs.fx3d && Prefs.parallax) par.start() else { par.stop(); resetFx() }
        } catch (t: Throwable) { showCrash(trace(t)) }
    }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (ready && drawerOpen) closeDrawer() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (drawerOpen) closeDrawer() }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { if (ready) gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        Util.onGalleryResult(this, req, res, data)
        if (req == REQ_BIND) {
            if (res == RESULT_OK) configureOrAdd(pendingWid) else try { host.deleteAppWidgetId(pendingWid) } catch (e: Throwable) {}
        } else if (req == REQ_CONFIG) {
            if (res == RESULT_OK) commitWidget(pendingWid) else try { host.deleteAppWidgetId(pendingWid) } catch (e: Throwable) {}
        } else if (req == REQ_VOICE && res == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) { openDrawer(false); search.setText(t); search.setSelection(search.text.length) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) { refreshWeather(true); if (ready) updateCard() }
    }

    // ---------------- مؤثرات 3D ----------------
    private fun applyParallax(nx: Float, ny: Float) {
        if (!::card.isInitialized || drawerOpen) return
        val d = resources.displayMetrics.density
        val k = Prefs.fxPower / 50f
        bg.translationX = -nx * 12 * d * k; bg.translationY = -ny * 12 * d * k
        wp.translationX = bg.translationX; wp.translationY = bg.translationY
        card.rotationY = nx * 8f * k; card.rotationX = -ny * 8f * k
        card.translationX = nx * 5 * d * k; card.translationY = ny * 4 * d * k
        dockWrap.translationX = nx * 9 * d * k; dockWrap.translationY = ny * 6 * d * k
        if (glOn) dock3d.tilt(nx * k, ny * k)
        pinGrid.translationX = nx * 9 * d * k; pinGrid.translationY = ny * 6 * d * k
        quoteBox.translationX = nx * 4 * d * k
        searchBar.translationX = nx * 3 * d * k; navBar.translationX = nx * 2 * d * k
    }

    private fun resetFx() {
        for (v in listOf<View>(bg, wp, card, dockWrap, pinGrid, quoteBox, searchBar, navBar)) {
            v.translationX = 0f; v.translationY = 0f; v.rotationX = 0f; v.rotationY = 0f
        }
        if (glOn) dock3d.tilt(0f, 0f)
    }

    // ---------------- helpers ----------------
    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun al(alpha: Int, c: Int = Prefs.accent) = (c and 0x00FFFFFF) or (alpha shl 24)
    private fun neo(r: Int, stroke: Int = 0x22FFFFFF) = neoDrawable(dp(r).toFloat(), stroke, dp(1))
    private fun hap(v: View) { if (Prefs.haptics) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
    private fun copy(t: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("neon", t)); toast("تم النسخ ✓")
    }

    private fun pressFx(l: View) {
        l.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                        hap(v); v.cameraDistance = 8000f * resources.displayMetrics.density
                        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
                    }
                    if (Prefs.fx3d && Prefs.tilt && v.width > 0 && v.height > 0) {
                        val nx = ((e.x / v.width - 0.5f) * 2f).coerceIn(-1f, 1f)
                        val ny = ((e.y / v.height - 0.5f) * 2f).coerceIn(-1f, 1f)
                        v.rotationY = nx * 16f; v.rotationX = -ny * 16f
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).rotationX(0f).rotationY(0f).setDuration(160).start()
            }
            false
        }
    }

    // ---------------- UI building ----------------
    private fun buildHome() {
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnLongClickListener { homeMenu(); true } }

        // ===== بطاقة الترحيب =====
        greetTv = tv("", 17f, Prefs.accent).apply { typeface = Typeface.create("cursive", Typeface.NORMAL); maxLines = 1 }
        nameTv = tv("", 30f).apply {
            typeface = Typeface.DEFAULT_BOLD; maxLines = 1
            setOnClickListener { prompt(if (isAr()) "اسمك" else "Your name", Prefs.userName) { n -> Prefs.userName = n; updateCard() } }
        }
        rowDate = InfoRow(GlyphView.CAL); rowTime = InfoRow(GlyphView.CLOCK)
        rowLoc = InfoRow(GlyphView.PIN); rowWx = InfoRow(GlyphView.CLOUD)
        rowLoc.root.setOnClickListener { onLocationTap() }
        rowWx.root.setOnClickListener { refreshWeather(true); toast(if (isAr()) "جارٍ تحديث الطقس…" else "Updating weather…") }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(greetTv); left.addView(nameTv)
        left.addView(rowDate.root, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })
        left.addView(rowTime.root, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        left.addView(rowLoc.root, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        left.addView(rowWx.root, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })

        analog = AnalogClockView(this)
        digital = tv("", 34f).apply { typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; visibility = View.GONE }
        val clockHolder = FrameLayout(this)
        clockHolder.addView(analog, FrameLayout.LayoutParams(MATCH, MATCH))
        clockHolder.addView(digital, FrameLayout.LayoutParams(MATCH, MATCH))

        card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(14), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1D1D21.toInt(), 0xFF0C0C0E.toInt()))
                .apply { cornerRadius = dp(30).toFloat(); setStroke(dp(1), 0x22FFFFFF) }
            elevation = dp(12).toFloat()
        }
        card.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        card.addView(clockHolder, LinearLayout.LayoutParams(dp(118), dp(118)))

        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        // ===== الدوك (التطبيقات المفضلة) =====
        dock = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        pinGrid = NoScrollGrid(this).apply {
            verticalSpacing = dp(6); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT); isVerticalScrollBarEnabled = false
        }
        val hint = tv(if (isAr()) "اضغط مطولاً على أي تطبيق في القائمة\nلتثبيته هنا 📌" else "Long-press any app in the drawer\nto pin it here 📌", 12f, 0x88FFFFFF.toInt())
            .apply { gravity = Gravity.CENTER; visibility = View.GONE }

        // ===== الاقتباس =====
        quote1 = tv("", 13f).apply { gravity = Gravity.CENTER }
        quote2 = tv("", 13f, Prefs.accent).apply { gravity = Gravity.CENTER }
        quoteBar = View(this)
        quoteL = tv("\u201C", 30f, Prefs.accent).apply { typeface = Typeface.create("serif", Typeface.BOLD) }
        quoteR = tv("\u201D", 30f, Prefs.accent).apply { typeface = Typeface.create("serif", Typeface.BOLD) }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        mid.addView(quote1, LinearLayout.LayoutParams(WRAP, WRAP))
        mid.addView(quote2, LinearLayout.LayoutParams(WRAP, WRAP))
        mid.addView(quoteBar, LinearLayout.LayoutParams(dp(28), dp(2)).apply { topMargin = dp(8) })
        quoteBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setOnClickListener { Prefs.quoteOffset = Prefs.quoteOffset + 1; updateQuote() }
        }
        quoteBox.addView(quoteL, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(12) })
        quoteBox.addView(mid, LinearLayout.LayoutParams(WRAP, WRAP))
        quoteBox.addView(quoteR, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })

        // ===== شريط البحث =====
        searchGlyph = GlyphView(this, GlyphView.SEARCH)
        micGlyph = GlyphView(this, GlyphView.WAVE).apply { setPadding(dp(4), dp(4), dp(4), dp(4)); setOnClickListener { startVoice() } }
        val sText = tv(if (isAr()) "ابحث في أي شيء…" else "Search anything…", 14f, 0xAAFFFFFF.toInt())
        searchBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(14), 0)
            background = neo(26); elevation = dp(8).toFloat()
            setOnClickListener { openDrawer(true) }
        }
        searchBar.addView(searchGlyph, LinearLayout.LayoutParams(dp(20), dp(20)))
        searchBar.addView(sText, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12) })
        searchBar.addView(micGlyph, LinearLayout.LayoutParams(dp(30), dp(30)))
        pressFx(searchBar)

        // ===== شريط التنقل السفلي =====
        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = neo(30); elevation = dp(8).toFloat()
        }
        val navApps = GlyphView(this, GlyphView.GRID).apply { color = 0xFFE6E6E6.toInt() }
        val navUser = GlyphView(this, GlyphView.PERSON).apply { color = 0xFFE6E6E6.toInt() }
        navHomeGlyph = GlyphView(this, GlyphView.HOME)
        homePill = FrameLayout(this).apply { elevation = dp(4).toFloat() }
        homePill.addView(navHomeGlyph, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        fun cell(inner: View, w: Int, h: Int, click: () -> Unit): LinearLayout {
            val c = LinearLayout(this).apply { gravity = Gravity.CENTER; isClickable = true }
            c.addView(inner, LinearLayout.LayoutParams(w, h))
            c.setOnClickListener { click() }
            pressFx(c)
            return c
        }
        navBar.addView(cell(navApps, dp(22), dp(22)) { openDrawer(false) }, LinearLayout.LayoutParams(0, MATCH, 1f))
        navBar.addView(cell(homePill, dp(60), dp(40)) { if (drawerOpen) closeDrawer() }, LinearLayout.LayoutParams(0, MATCH, 1f))
        navBar.addView(cell(navUser, dp(22), dp(22)) { startActivity(Intent(this, SettingsActivity::class.java)) }, LinearLayout.LayoutParams(0, MATCH, 1f))

        // ===== التجميع =====
        // المحتوى العلوي قابل للتمرير، والجزء السفلي (اقتباس/بحث/تنقل) ثابت دائماً
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnLongClickListener { homeMenu(); true } }
        homeScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            setOnLongClickListener { homeMenu(); true }
        }
        homeScroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        content.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), dp(10), dp(14), 0) })
        content.addView(widgetBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), 0, dp(14), 0) })
        dockWrap = FrameLayout(this)
        dockWrap.addView(dock, FrameLayout.LayoutParams(MATCH, WRAP))
        dock3d = Dock3DView(this).apply {
            visibility = View.GONE
            onTap = { i -> dockApps.getOrNull(i)?.let { Apps.launch(this@MainActivity, it) } }
            onLong = { i -> dockApps.getOrNull(i)?.let { appMenu(it) } }
        }
        dockWrap.addView(dock3d, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(dockWrap, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(10), dp(16), dp(10), 0) })
        content.addView(pinGrid, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(10), dp(8), dp(10), dp(8)) })
        hint.setPadding(0, dp(16), 0, dp(16))
        content.addView(hint, LinearLayout.LayoutParams(MATCH, WRAP))
        pinGrid.emptyView = hint
        home.addView(homeScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        home.addView(quoteBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(24), dp(6), dp(24), dp(14)) })
        home.addView(searchBar, LinearLayout.LayoutParams(MATCH, dp(52)).apply { setMargins(dp(16), 0, dp(16), dp(12)) })
        home.addView(navBar, LinearLayout.LayoutParams(MATCH, dp(60)).apply { setMargins(dp(16), 0, dp(16), dp(4)) })
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        search = EditText(this).apply {
            hint = if (isAr()) "ابحث عن تطبيق أو في الويب…" else "Search apps or the web…"
            setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
            background = null; textSize = 15f; setPadding(dp(10), dp(12), dp(10), dp(12))
            isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString().trim(); refreshDrawer() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val l = drawerList()
            if (query.isNotEmpty() && l.isNotEmpty()) { Apps.launch(this, l[0]); closeDrawer() }
            else if (query.isNotEmpty()) webSearch(query)
            true
        }
        drawerSearchGlyph = GlyphView(this, GlyphView.SEARCH)
        drawerMic = GlyphView(this, GlyphView.WAVE).apply { setPadding(dp(4), dp(4), dp(4), dp(4)); setOnClickListener { startVoice() } }
        searchBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(12), 0) }
        searchBox.addView(drawerSearchGlyph, LinearLayout.LayoutParams(dp(20), dp(20)))
        searchBox.addView(search, LinearLayout.LayoutParams(0, WRAP, 1f))
        searchBox.addView(drawerMic, LinearLayout.LayoutParams(dp(30), dp(30)))

        calcRow = tv("", 16f).apply { setPadding(dp(16), dp(10), dp(16), dp(10)); visibility = View.GONE; maxLines = 1 }
        webRow = tv("", 14f).apply { setPadding(dp(16), dp(10), dp(16), dp(10)); visibility = View.GONE; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }

        suggestRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        suggestWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        suggestTitle = tv(if (isAr()) "⭐ المقترحة" else "⭐ Suggested", 12f, 0x99FFFFFF.toInt()).apply { setPadding(dp(16), 0, dp(16), 0) }
        suggestWrap.addView(suggestTitle)
        suggestWrap.addView(suggestRow, LinearLayout.LayoutParams(MATCH, WRAP))

        drawerGrid = GridView(this).apply {
            verticalSpacing = dp(6); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT); isVerticalScrollBarEnabled = false
            setPaddingRelative(dp(4), 0, dp(22), dp(8))
        }
        indexBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE }
        val body = FrameLayout(this)
        body.addView(drawerGrid, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(indexBar, FrameLayout.LayoutParams(dp(22), MATCH, Gravity.END).apply { setMargins(0, dp(8), 0, dp(8)) })

        drawer.addView(searchBox, LinearLayout.LayoutParams(MATCH, dp(50)).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
        drawer.addView(calcRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), 0, dp(12), dp(6)) })
        drawer.addView(webRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), 0, dp(12), dp(6)) })
        drawer.addView(suggestWrap, LinearLayout.LayoutParams(MATCH, WRAP))
        drawer.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------------- preferences / state ----------------
    private fun autoWallpaper() {
        if (!Prefs.autoWp) return
        val c = Calendar.getInstance(); val day = c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
        if (Prefs.wpDay != day) {
            Prefs.wpDay = day; Prefs.wallpaper = (maxOf(Prefs.wallpaper, 0) + 1) % Util.WP_COUNT; Prefs.wpVer = Prefs.wpVer + 1
        }
    }

    private fun updateBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        val b = maxOf(Prefs.blur, if (drawerOpen && Prefs.drawerBlur) 20 else 0)
        val fx = if (b > 0) RenderEffect.createBlurEffect(b.toFloat(), b.toFloat(), Shader.TileMode.CLAMP) else null
        wp.setRenderEffect(fx); bg.setRenderEffect(fx)
    }

    private fun applyPrefs() {
        autoWallpaper()
        val ac = Prefs.accent
        val ns = "${Prefs.shape}|${Prefs.iconSize}|${Prefs.glow}|${Prefs.accent}|${Prefs.tile}|${Prefs.themedIcons}"
        val changed = ns != sig
        if (changed) { sig = ns; Icons.clear() }

        // الخلفية
        val waves = Prefs.bgMode == 0
        bg.visibility = if (waves) View.VISIBLE else View.GONE
        bg.accent = ac
        wp.visibility = if (waves) View.GONE else View.VISIBLE
        dim.visibility = if (waves) View.GONE else View.VISIBLE
        if (!waves) {
            val k = "${Prefs.wallpaper}:${Prefs.wpVer}"
            if (k != wpKey) { wpKey = k; wp.setImageBitmap(Util.decode(this, Prefs.wallpaper, resources.displayMetrics.widthPixels)) }
            dim.setBackgroundColor(Color.argb(Prefs.dim * 255 / 100, 0, 0, 0))
        }
        updateBlur()
        val os = if (Prefs.fx3d && Prefs.parallax) 1.12f else 1f
        bg.scaleX = os; bg.scaleY = os; wp.scaleX = os; wp.scaleY = os

        // البطاقة
        card.visibility = if (Prefs.showCard) View.VISIBLE else View.GONE
        greetTv.setTextColor(ac)
        for (r in listOf(rowDate, rowTime, rowLoc, rowWx)) { r.glyph.color = ac; r.t1.setTextColor(Color.WHITE); r.t2.setTextColor(ac) }
        analog.accent = ac
        analog.visibility = if (Prefs.cardClock == 0) View.VISIBLE else View.GONE
        digital.visibility = if (Prefs.cardClock == 1) View.VISIBLE else View.GONE
        digital.setShadowLayer(24f, 0f, 0f, ac)
        // الاقتباس والبحث والتنقل
        quoteL.setTextColor(ac); quoteR.setTextColor(ac); quote2.setTextColor(ac)
        quoteBar.background = roundBg(ac, dp(2))
        updateQuote()
        searchGlyph.color = ac; micGlyph.color = ac
        (searchBar.background as GradientDrawable).setStroke(dp(1), al(0x55, ac))
        searchBar.visibility = if (Prefs.showSearch) View.VISIBLE else View.GONE
        navHomeGlyph.color = ac
        homePill.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat(); setColor(0xFF0E0E10.toInt()); setStroke(dp(2), ac)
        }
        (navBar.background as GradientDrawable).setStroke(dp(1), 0x22FFFFFF)
        navBar.visibility = if (Prefs.showNav) View.VISIBLE else View.GONE

        // القائمة
        drawerSearchGlyph.color = ac; drawerMic.color = ac
        searchBox.background = neo(26, al(0x66, ac))
        calcRow.background = neo(16, al(0x66, ac)); calcRow.setTextColor(ac)
        webRow.background = neo(16, 0x22FFFFFF); webRow.setTextColor(Color.WHITE)
        val rr = dp(28).toFloat()
        drawer.background = GradientDrawable().apply {
            setColor(Color.argb(Prefs.drawerAlpha * 255 / 100, 10, 10, 13))
            cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
            setStroke(dp(2), al(0x99, ac))
        }
        pinGrid.numColumns = Prefs.columns; drawerGrid.numColumns = Prefs.columns
        WindowCompat.getInsetsController(window, root).let { c ->
            if (Prefs.hideStatus) c.hide(WindowInsetsCompat.Type.statusBars()) else c.show(WindowInsetsCompat.Type.statusBars())
        }
        updateCard()
        refreshWidgets()
        refreshLists()
        if (changed) loadApps()
    }

    // ---------------- البطاقة: التحية والتاريخ والطقس ----------------
    private fun greeting(ar: Boolean): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (ar) when (h) { in 5..11 -> "صباح الخير"; in 12..15 -> "طاب يومك"; in 16..20 -> "مساء الخير"; else -> "طابت ليلتك" }
        else when (h) { in 5..11 -> "Good Morning,"; in 12..16 -> "Good Afternoon,"; in 17..20 -> "Good Evening,"; else -> "Good Night," }
    }

    private fun period(ar: Boolean): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (ar) when (h) { in 5..11 -> "صباحاً"; in 12..15 -> "ظهراً"; in 16..19 -> "مساءً"; else -> "ليلاً" }
        else when (h) { in 5..11 -> "Morning"; in 12..16 -> "Afternoon"; in 17..20 -> "Evening"; else -> "Night" }
    }

    private fun updateCard() {
        if (!::rowDate.isInitialized) return
        val ar = isAr(); val loc = Locale.getDefault(); val now = Date()
        greetTv.text = greeting(ar)
        nameTv.text = Prefs.userName.ifEmpty { if (ar) "صديقي" else "Friend" }
        rowDate.t1.text = SimpleDateFormat("dd-MM-yyyy", loc).format(now)
        rowDate.t2.text = SimpleDateFormat("EEEE", loc).format(now)
        rowTime.t1.text = SimpleDateFormat(if (Prefs.clock24) "HH:mm" else "hh:mm a", loc).format(now)
        rowTime.t2.text = period(ar) + (if (Prefs.showBattery && battText.isNotEmpty()) "  •  $battText" else "")
        digital.text = SimpleDateFormat(if (Prefs.clock24) "HH:mm" else "h:mm", loc).format(now)

        val show = Prefs.showWeather
        rowLoc.root.visibility = if (show) View.VISIBLE else View.GONE
        rowWx.root.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val w = Weather.cached()
        if (w == null) {
            val need = Prefs.cityManual.isEmpty() && !Weather.hasPerm(this)
            rowLoc.t1.text = if (need) (if (ar) "فعّل الموقع" else "Enable location") else (if (ar) "جارٍ التحديد…" else "Locating…")
            rowLoc.t2.text = if (ar) "لعرض الطقس" else "to show weather"
            rowWx.t1.text = "--°"; rowWx.t2.text = ""
        } else {
            val parts = w.city.split("،", ",")
            rowLoc.t1.text = parts[0].trim().ifEmpty { if (ar) "موقعك الحالي" else "Current location" }
            rowLoc.t2.text = parts.getOrElse(1) { "" }.trim()
            val t = if (Prefs.tempF) w.tempC * 9f / 5f + 32f else w.tempC
            rowWx.t1.text = "${t.roundToInt()}°" + (if (Prefs.tempF) "F" else "C")
            rowWx.t2.text = Weather.desc(w.code, w.isDay)
            rowWx.glyph.kind = Weather.glyph(w.code, w.isDay)
        }
    }

    private fun updateQuote() {
        val on = Prefs.quoteMode != 2
        if (!on) { quoteBox.visibility = View.GONE; return }
        val q = Quotes.current()
        quote1.text = q.first; quote2.text = q.second
        quote2.visibility = if (q.second.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshWeather(force: Boolean) {
        if (!Prefs.showWeather) return
        if (!force && Weather.isFresh()) return
        Weather.refresh(this) { runOnUiThread { if (ready) updateCard() } }
    }

    private fun maybeAskLocation() {
        if (!Prefs.showWeather || Prefs.cityManual.isNotEmpty() || Weather.hasPerm(this)) return
        if (Prefs.sp.getBoolean("loc_asked", false)) return
        Prefs.sp.edit().putBoolean("loc_asked", true).apply()
        try { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC) } catch (e: Throwable) {}
    }

    private fun onLocationTap() {
        if (Prefs.cityManual.isEmpty() && !Weather.hasPerm(this)) {
            val items = if (isAr()) arrayOf("📍 السماح بالوصول للموقع", "🏙 إدخال مدينة يدوياً") else arrayOf("📍 Allow location", "🏙 Enter a city")
            AlertDialog.Builder(this).setItems(items) { _, i ->
                if (i == 0) {
                    try { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC) } catch (e: Throwable) {}
                    if (!shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION) && Prefs.sp.getBoolean("loc_asked", false)) {
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Throwable) {}
                    }
                    Prefs.sp.edit().putBoolean("loc_asked", true).apply()
                } else askCity()
            }.show()
        } else { refreshWeather(true); toast(if (isAr()) "جارٍ تحديث الطقس…" else "Updating weather…") }
    }

    private fun askCity() = prompt(if (isAr()) "اسم المدينة" else "City name", Prefs.cityManual) { n -> Prefs.cityManual = n; refreshWeather(true); updateCard() }

    private fun updateBattery(i: Intent) {
        val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (lv >= 0) battText = "${if (ch) "⚡" else "🔋"} ${lv * 100 / sc}%"
        if (ready) updateCard()
    }

    // ---------------- التطبيقات ----------------
    private fun loadApps() {
        Thread {
            val l = Apps.load(this); val px = dp(Prefs.iconSize)
            initDock(l)
            l.forEach { Icons.get(this, it, px) }
            runOnUiThread { all = l; refreshLists() }
        }.start()
    }

    private fun initDock(l: List<AppInfo>) {
        if (Prefs.sp.getBoolean("dock_init", false) || l.isEmpty()) return
        val intents = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE), Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
        val pk = intents.mapNotNull { packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { p -> l.any { it.pkg == p } }.distinct()
        Prefs.setList("dock", pk); Prefs.sp.edit().putBoolean("dock_init", true).apply()
    }

    private fun visible(): List<AppInfo> {
        val h = Prefs.list("hidden").toSet(); val l = all.filter { it.pkg !in h }
        return when (Prefs.sortMode) {
            1 -> l.sortedByDescending { Prefs.uses(it.pkg) }
            2 -> l.sortedByDescending { it.installed }
            else -> l
        }
    }
    private fun drawerList() = visible().filter { it.label.contains(query, true) }

    private fun refreshLists() {
        val by = all.associateBy { it.pkg }
        val folders = Prefs.list("folders")
        val items = Prefs.list("pins").mapNotNull { e ->
            if (e.startsWith("f:")) { val id = e.substring(2); if (id in folders) HomeItem(null, id) else null }
            else by[e]?.let { HomeItem(it, null) }
        }
        pinGrid.adapter = HomeAdapter(items)
        dock.removeAllViews()
        val d = Prefs.list("dock").mapNotNull { by[it] }
        d.forEach { a ->
            val v = appView(a, true)
            v.setOnClickListener { Apps.launch(this, a) }
            v.setOnLongClickListener { appMenu(a); true }
            dock.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val dockVis = if (d.isEmpty() || !Prefs.showDock) View.GONE else View.VISIBLE
        dock.visibility = dockVis; dockWrap.visibility = dockVis
        dockApps = d
        glOn = Prefs.glIcons && Prefs.fx3d && d.isNotEmpty() && dockVis == View.VISIBLE
        if (glOn) {
            val px = dp(Prefs.iconSize)
            for (k in 0 until dock.childCount) (dock.getChildAt(k) as LinearLayout).getChildAt(0).visibility = View.INVISIBLE
            dock3d.setIcons(d.map { Icons.getBare(this, it, px) }, px, dp(6) + px / 2, Prefs.accent)
            dock3d.visibility = if (drawerOpen) View.INVISIBLE else View.VISIBLE
        } else dock3d.visibility = View.GONE
        refreshDrawer()
    }

    private fun looksLikeUrl(q: String) = !q.contains(' ') && q.contains('.') && Patterns.WEB_URL.matcher(q).matches()

    private fun webSearch(q: String) {
        try {
            val u = if (looksLikeUrl(q)) (if (q.startsWith("http")) q else "https://$q") else Engines.url(q)
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            closeDrawer()
        } catch (e: Exception) { toast(if (isAr()) "تعذر فتح المتصفح" else "Can't open browser") }
    }

    private fun refreshDrawer() {
        val l = drawerList()
        drawerGrid.adapter = Adapter(l)
        buildIndex(l)

        val r = if (query.isNotEmpty()) Calc.eval(query) else null
        if (r != null) {
            calcRow.visibility = View.VISIBLE; calcRow.text = "🧮  $query = $r"
            calcRow.setOnClickListener { copy(r) }
        } else calcRow.visibility = View.GONE

        if (query.isEmpty()) webRow.visibility = View.GONE
        else {
            webRow.visibility = View.VISIBLE
            webRow.text = if (looksLikeUrl(query)) "🌐  " + (if (isAr()) "فتح " else "Open ") + query
            else "🔍  " + (if (isAr()) "بحث في ${Engines.name()} عن «$query»" else "Search ${Engines.name()} for “$query”")
            webRow.setOnClickListener { webSearch(query) }
        }

        suggestRow.removeAllViews()
        val sug = if (query.isEmpty() && Prefs.suggest) visible().filter { Prefs.uses(it.pkg) > 0 }.sortedByDescending { Prefs.uses(it.pkg) }.take(5) else emptyList()
        sug.forEach { a ->
            val v = appView(a, true)
            v.setOnClickListener { Apps.launch(this, a); closeDrawer() }
            v.setOnLongClickListener { appMenu(a); true }
            suggestRow.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        suggestWrap.visibility = if (sug.isEmpty()) View.GONE else View.VISIBLE
    }

    /** شريط فهرس الحروف الجانبي للتمرير السريع */
    private fun buildIndex(l: List<AppInfo>) {
        indexBar.removeAllViews()
        if (!Prefs.alphaIndex || query.isNotEmpty() || Prefs.sortMode != 0 || l.size < 24) { indexBar.visibility = View.GONE; return }
        val letters = ArrayList<String>(); val pos = ArrayList<Int>()
        l.forEachIndexed { i, a ->
            val t = a.label.trim().take(1).uppercase()
            val ch = if (t.isEmpty() || !t[0].isLetter()) "#" else t
            if (letters.isEmpty() || letters[letters.size - 1] != ch) { letters.add(ch); pos.add(i) }
        }
        for (ch in letters) {
            indexBar.addView(tv(ch, 9f, al(0xDD)).apply { gravity = Gravity.CENTER; includeFontPadding = false },
                LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        indexBar.visibility = View.VISIBLE
        indexBar.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    indexTouch = true
                    val idx = (e.y / v.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                    drawerGrid.setSelection(pos[idx])
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> indexTouch = false
            }
            true
        }
    }

    // ---------------- views ----------------
    private fun label(t: String) = tv(t, Prefs.labelSize.toFloat()).apply {
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        setShadowLayer(6f, 0f, 1f, Color.BLACK); setPadding(dp(2), dp(4), dp(2), 0)
    }

    private fun appView(a: AppInfo, labels: Boolean): LinearLayout {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) }
        val px = dp(Prefs.iconSize)
        l.addView(ImageView(this).apply { setImageBitmap(Icons.get(this@MainActivity, a, px)) }, LinearLayout.LayoutParams(px, px))
        if (labels && Prefs.labels) l.addView(label(a.label), LinearLayout.LayoutParams(MATCH, WRAP))
        pressFx(l)
        return l
    }

    private fun folderIcon(apps: List<AppInfo>): Bitmap {
        val px = dp(Prefs.iconSize)
        val base = IconShaper.render(ColorDrawable(Color.TRANSPARENT), px, Prefs.shape, Prefs.accent, Prefs.glow, if (Prefs.tile >= 3) Prefs.tile else 2)
        val c = Canvas(base)
        val mini = (px * 0.32f).toInt(); val gap = (px * 0.06f).toInt(); val start = (px - 2 * mini - gap) / 2
        apps.take(4).forEachIndexed { i, a ->
            val b = Icons.get(this, a, px)
            c.drawBitmap(Bitmap.createScaledBitmap(b, mini, mini, true), (start + (i % 2) * (mini + gap)).toFloat(), (start + (i / 2) * (mini + gap)).toFloat(), null)
        }
        return base
    }

    private fun folderView(id: String): View {
        val l = Prefs.list("fd_$id"); val by = all.associateBy { it.pkg }
        val apps = l.drop(1).mapNotNull { by[it] }
        val px = dp(Prefs.iconSize)
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) }
        v.addView(ImageView(this).apply { setImageBitmap(folderIcon(apps)) }, LinearLayout.LayoutParams(px, px))
        if (Prefs.labels) v.addView(label(l.firstOrNull() ?: "مجلد"), LinearLayout.LayoutParams(MATCH, WRAP))
        pressFx(v)
        v.setOnClickListener { openFolder(id) }
        v.setOnLongClickListener { folderMenu(id); true }
        return v
    }

    inner class Adapter(private val l: List<AppInfo>) : BaseAdapter() {
        override fun getCount() = l.size
        override fun getItem(p: Int) = l[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = l[p]; val v = appView(a, Prefs.labels)
            v.setOnClickListener { Apps.launch(this@MainActivity, a); closeDrawer() }
            v.setOnLongClickListener { appMenu(a); true }
            return v
        }
    }

    private inner class HomeAdapter(private val l: List<HomeItem>) : BaseAdapter() {
        override fun getCount() = l.size
        override fun getItem(p: Int) = l[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val it = l[p]
            val f = it.folder
            if (f != null) return folderView(f)
            val a = it.app!!; val v = appView(a, Prefs.labels)
            v.setOnClickListener { Apps.launch(this@MainActivity, a) }
            v.setOnLongClickListener { appMenu(a); true }
            return v
        }
    }

    // ---------------- menus & dialogs ----------------
    private fun prompt(title: String, init: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(init); setSingleLine() }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton(if (isAr()) "حفظ" else "Save") { _, _ -> ok(et.text.toString().replace("|", "").trim()) }
            .setNegativeButton(if (isAr()) "إلغاء" else "Cancel", null).show()
    }

    private fun shortcutsOf(pkg: String): List<ShortcutInfo> {
        if (Build.VERSION.SDK_INT < 25) return emptyList()
        var res: List<ShortcutInfo>? = null
        try {
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            if (la.hasShortcutHostPermission()) {
                val q = LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
                res = la.getShortcuts(q, android.os.Process.myUserHandle())
            }
        } catch (e: Throwable) {}
        return res ?: emptyList()
    }

    private fun startShortcut(si: ShortcutInfo) {
        if (Build.VERSION.SDK_INT < 25) return
        try { (getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps).startShortcut(si, null, null) }
        catch (e: Throwable) { toast("تعذر فتح الاختصار") }
    }

    private fun appMenu(a: AppInfo) {
        val pins = Prefs.list("pins").toMutableList(); val dk = Prefs.list("dock").toMutableList()
        val opts = ArrayList<Pair<String, () -> Unit>>()
        fun add(t: String, f: () -> Unit) { opts.add(t to f) }
        for (si in shortcutsOf(a.pkg).take(4)) add("⚡ " + (si.shortLabel?.toString() ?: si.id)) { startShortcut(si) }
        if (a.pkg in pins) add("↩ إزالة من الشاشة الرئيسية") { pins.remove(a.pkg); Prefs.setList("pins", pins) }
        else add("📌 تثبيت في الشاشة الرئيسية") { pins.add(a.pkg); Prefs.setList("pins", pins) }
        if (a.pkg in dk) add("↩ إزالة من الدوك") { dk.remove(a.pkg); Prefs.setList("dock", dk) }
        else if (dk.size < 5) add("⚓ إضافة إلى الدوك") { dk.add(a.pkg); Prefs.setList("dock", dk) }
        add("📁 إضافة إلى مجلد") { folderPicker(a) }
        add("✏ إعادة تسمية") {
            prompt("اسم التطبيق", a.label) { n ->
                if (n.isEmpty()) Prefs.sp.edit().remove("ren_${a.pkg}").apply() else Prefs.sp.edit().putString("ren_${a.pkg}", n).apply()
                loadApps()
            }
        }
        add("🙈 إخفاء التطبيق") { Prefs.setList("hidden", Prefs.list("hidden") + a.pkg) }
        add("ℹ معلومات التطبيق") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) }
        add("🗑 إلغاء التثبيت") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) }
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(opts.map { it.first }.toTypedArray()) { _, i -> opts[i].second(); refreshLists() }.show()
    }

    private fun folderPicker(a: AppInfo) {
        val ids = Prefs.list("folders")
        val names = ids.map { Prefs.list("fd_$it").firstOrNull() ?: "مجلد" } + "➕ مجلد جديد"
        AlertDialog.Builder(this).setTitle("اختر مجلداً").setItems(names.toTypedArray()) { _, i ->
            if (i == ids.size) {
                prompt("اسم المجلد", "") { n ->
                    val id = System.currentTimeMillis().toString()
                    Prefs.setList("folders", ids + id); Prefs.setList("fd_$id", listOf(n.ifEmpty { "مجلد" }, a.pkg))
                    Prefs.setList("pins", Prefs.list("pins") + "f:$id"); refreshLists()
                }
            } else {
                val id = ids[i]; val l = Prefs.list("fd_$id")
                if (a.pkg !in l) Prefs.setList("fd_$id", l + a.pkg)
                refreshLists()
            }
        }.show()
    }

    private fun openFolder(id: String) {
        val l = Prefs.list("fd_$id"); val by = all.associateBy { it.pkg }
        val apps = l.drop(1).mapNotNull { by[it] }
        val g = GridView(this).apply { numColumns = minOf(Prefs.columns, 4); stretchMode = GridView.STRETCH_COLUMN_WIDTH; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val dlg = AlertDialog.Builder(this).setTitle("📁 " + (l.firstOrNull() ?: "مجلد")).setView(g).create()
        g.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val a = apps[p]; val v = appView(a, true)
                v.setOnClickListener { dlg.dismiss(); Apps.launch(this@MainActivity, a) }
                v.setOnLongClickListener {
                    dlg.dismiss()
                    val rest = l - a.pkg
                    if (rest.size <= 1) deleteFolder(id) else Prefs.setList("fd_$id", rest)
                    refreshLists(); toast("أُزيل من المجلد"); true
                }
                return v
            }
        }
        dlg.show()
    }

    private fun deleteFolder(id: String) {
        Prefs.setList("folders", Prefs.list("folders") - id); Prefs.setList("pins", Prefs.list("pins") - "f:$id")
        Prefs.sp.edit().remove("fd_$id").apply()
    }

    private fun folderMenu(id: String) {
        val l = Prefs.list("fd_$id")
        AlertDialog.Builder(this).setItems(arrayOf("✏ إعادة تسمية المجلد", "🗑 حذف المجلد")) { _, i ->
            if (i == 0) prompt("اسم المجلد", l.firstOrNull() ?: "") { n -> Prefs.setList("fd_$id", listOf(n.ifEmpty { "مجلد" }) + l.drop(1)); refreshLists() }
            else { deleteFolder(id); refreshLists() }
        }.show()
    }

    private fun homeMenu() {
        val items = arrayOf("🖼 تغيير الخلفية", "🧩 إضافة ودجت", "🗑 إزالة ودجت", "📲 تعيين كخلفية للنظام", "🔄 تحديث الطقس", "⚙ إعدادات اللانشر")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> Util.pickWallpaper(this) { Prefs.bgMode = 1; applyPrefs() }
                1 -> addWidgetFlow()
                2 -> removeWidgetFlow()
                3 -> Util.setSystemWallpaper(this)
                4 -> { refreshWeather(true); toast(if (isAr()) "جارٍ تحديث الطقس…" else "Updating weather…") }
                else -> startActivity(Intent(this, SettingsActivity::class.java))
            }
        }.show()
    }

    // ---------------- voice ----------------
    private fun startVoice() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, if (isAr()) "تحدّث الآن…" else "Speak now…"), REQ_VOICE)
        } catch (e: Exception) { toast(if (isAr()) "البحث الصوتي غير متاح" else "Voice search unavailable") }
    }

    // ---------------- widgets ----------------
    private fun addWidgetFlow() {
        val provs: List<AppWidgetProviderInfo> = try { awm.installedProviders } catch (e: Throwable) { emptyList() }
        if (provs.isEmpty()) { toast("لا توجد ودجات متاحة"); return }
        val sorted = provs.sortedBy { it.loadLabel(packageManager).toString() }
        val names = sorted.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("اختر ودجت").setItems(names) { _, i ->
            val p = sorted[i]
            val id = host.allocateAppWidgetId(); pendingWid = id
            try {
                if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) configureOrAdd(id)
                else startActivityForResult(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), REQ_BIND)
            } catch (e: Throwable) { try { host.deleteAppWidgetId(id) } catch (x: Throwable) {}; toast("تعذر إضافة الودجت") }
        }.show()
    }

    private fun configureOrAdd(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null); return } catch (e: Throwable) {}
        }
        commitWidget(id)
    }

    private fun commitWidget(id: Int) { Prefs.setList("widgets", Prefs.list("widgets") + id.toString()); refreshWidgets() }

    private fun removeWidgetFlow() {
        val ids = Prefs.list("widgets")
        if (ids.isEmpty()) { toast("لا توجد ودجات"); return }
        val names = ids.map { s -> awm.getAppWidgetInfo(s.toIntOrNull() ?: -1)?.loadLabel(packageManager)?.toString() ?: "ودجت $s" }
        AlertDialog.Builder(this).setTitle("إزالة ودجت").setItems(names.toTypedArray()) { _, i ->
            try { host.deleteAppWidgetId(ids[i].toInt()) } catch (e: Throwable) {}
            Prefs.setList("widgets", ids - ids[i]); refreshWidgets()
        }.show()
    }

    private fun refreshWidgets() {
        widgetBox.removeAllViews()
        for (s in Prefs.list("widgets")) {
            val id = s.toIntOrNull() ?: continue
            try {
                val info = awm.getAppWidgetInfo(id) ?: continue
                val v = host.createView(this, id, info)
                v.setAppWidget(id, info)
                widgetBox.addView(v, LinearLayout.LayoutParams(MATCH, info.minHeight.coerceIn(dp(70), dp(300))).apply { topMargin = dp(8) })
            } catch (e: Throwable) {}
        }
        widgetBox.visibility = if (widgetBox.childCount == 0) View.GONE else View.VISIBLE
    }

    // ---------------- drawer ----------------
    private fun openDrawer(focus: Boolean) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        if (glOn) dock3d.visibility = View.INVISIBLE
        drawer.translationY = root.height.toFloat()
        if (Prefs.fx3d) {
            drawer.pivotX = root.width / 2f; drawer.pivotY = root.height.toFloat(); drawer.rotationX = 22f
            home.pivotX = root.width / 2f; home.pivotY = root.height / 2f
            home.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).rotationX(-14f).setDuration(260).start()
        } else home.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(220).start()
        drawer.animate().translationY(0f).rotationX(0f).setDuration(280).start()
        updateBlur()
        if (focus) root.postDelayed({
            search.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }, 280)
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        if (glOn) dock3d.visibility = View.VISIBLE
        home.animate().alpha(1f).scaleX(1f).scaleY(1f).rotationX(0f).setDuration(240).start()
        drawer.animate().translationY(root.height.toFloat()).rotationX(if (Prefs.fx3d) 22f else 0f).setDuration(230).withEndAction {
            drawer.visibility = View.GONE; drawer.rotationX = 0f; search.setText("")
        }.start()
        updateBlur()
    }

    private fun expandNotifications() {
        try {
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(getSystemService("statusbar"))
        } catch (e: Exception) {}
    }
}
