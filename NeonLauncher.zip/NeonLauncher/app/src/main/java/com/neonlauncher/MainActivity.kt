package com.neonlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.view.WindowCompat
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var wp: ImageView
    private lateinit var dim: View
    private lateinit var home: LinearLayout
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var pill: TextView
    private lateinit var pinGrid: GridView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var drawerGrid: GridView
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private var all = listOf<AppInfo>()
    private var sig = ""
    private var wpShown = -1
    private var drawerOpen = false
    private var query = ""

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadApps() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        wp = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wp, FrameLayout.LayoutParams(MATCH, MATCH))
        dim = View(this)
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))
        buildHome(); buildDrawer()
        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop; val bt = ins.systemWindowInsetBottom
            home.setPadding(dp(16), t + dp(24), dp(16), bt + dp(12))
            drawer.setPadding(dp(8), t + dp(12), dp(8), bt)
            ins
        }

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                if (abs(dy) < dp(80) || abs(vy) < 800 || abs(dy) < abs(e2.x - e1.x)) return false
                if (drawerOpen) { if (dy > 0 && !drawerGrid.canScrollVertically(-1)) closeDrawer() }
                else if (dy < 0) openDrawer() else expandNotifications()
                return true
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        registerReceiver(rx, f)
        loadApps()
    }

    override fun onDestroy() { super.onDestroy(); try { unregisterReceiver(rx) } catch (e: Exception) {} }
    override fun onResume() { super.onResume(); applyPrefs() }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (drawerOpen) closeDrawer() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (drawerOpen) closeDrawer() }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }

    private fun buildHome() {
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setOnLongClickListener { homeMenu(); true } }
        clock = TextClock(this).apply {
            textSize = 72f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); setShadowLayer(14f, 0f, 2f, 0x99000000.toInt())
        }
        date = TextClock(this).apply {
            textSize = 17f; gravity = Gravity.CENTER; format12Hour = "EEEE، d MMMM"; format24Hour = "EEEE، d MMMM"
            setShadowLayer(8f, 0f, 1f, 0x99000000.toInt())
        }
        pill = tv("🔍   ابحث في التطبيقات", 15f, 0xCCFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = roundBg(0x33FFFFFF, dp(28)); setOnClickListener { openDrawer() }
        }
        pinGrid = GridView(this).apply {
            verticalSpacing = dp(6); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT); isVerticalScrollBarEnabled = false
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(6), dp(8), dp(6))
            background = roundBg(0x55000000, dp(34))
        }
        home.addView(clock, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(24) })
        home.addView(date, LinearLayout.LayoutParams(MATCH, WRAP))
        home.addView(pill, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(24), dp(12), 0) })
        home.addView(pinGrid, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(16) })
        home.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        search = EditText(this).apply {
            hint = "ابحث عن تطبيق…"; setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
            background = roundBg(0x33FFFFFF, dp(26)); setPadding(dp(20), dp(12), dp(20), dp(12))
            isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString().trim(); refreshDrawer() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            drawerList().singleOrNull()?.let { Apps.launch(this, it); closeDrawer() }; true
        }
        drawerGrid = GridView(this).apply {
            verticalSpacing = dp(6); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT); isVerticalScrollBarEnabled = false
        }
        drawer.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(8), dp(12), dp(10)) })
        drawer.addView(drawerGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun applyPrefs() {
        val ns = "${Prefs.shape}|${Prefs.iconSize}|${Prefs.glow}|${Prefs.accent}"
        val changed = ns != sig
        if (changed) { sig = ns; Icons.clear() }
        if (wpShown != Prefs.wallpaper) {
            wpShown = Prefs.wallpaper
            wp.setImageBitmap(Util.decode(this, wpShown, resources.displayMetrics.widthPixels))
        }
        dim.setBackgroundColor(Color.argb(Prefs.dim * 255 / 100, 0, 0, 0))
        val f = if (Prefs.clock24) "HH:mm" else "h:mm"
        clock.format12Hour = f; clock.format24Hour = f
        date.setTextColor(Prefs.accent)
        (pill.background as GradientDrawable).setStroke(dp(1), Prefs.accent)
        (dock.background as GradientDrawable).setStroke(dp(1), Prefs.accent and 0x00FFFFFF or 0x66000000)
        drawer.setBackgroundColor(Color.argb(Prefs.drawerAlpha * 255 / 100, 8, 8, 16))
        pinGrid.numColumns = Prefs.columns; drawerGrid.numColumns = Prefs.columns
        refreshLists()
        if (changed) loadApps()
    }

    private fun loadApps() {
        Thread {
            val l = Apps.load(this); val px = dp(Prefs.iconSize)
            initDock(l)
            l.forEach { Icons.get(this, it, px) }
            runOnUiThread { all = l; refreshLists() }
        }.start()
    }

    private fun initDock(l: List<AppInfo>) {
        if (Prefs.sp.getBoolean("dock_init", false) || l.isEmpty()) return
        val intents = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE), Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
        val pk = intents.mapNotNull { packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { p -> l.any { it.pkg == p } }.distinct()
        Prefs.setList("dock", pk); Prefs.sp.edit().putBoolean("dock_init", true).apply()
    }

    private fun visible(): List<AppInfo> { val h = Prefs.list("hidden").toSet(); return all.filter { it.pkg !in h } }
    private fun drawerList() = visible().filter { it.label.contains(query, true) }

    private fun refreshLists() {
        val by = all.associateBy { it.pkg }
        pinGrid.adapter = Adapter(Prefs.list("pins").mapNotNull { by[it] }, false)
        dock.removeAllViews()
        val d = Prefs.list("dock").mapNotNull { by[it] }
        d.forEach { a ->
            val v = appView(a, false)
            v.setOnClickListener { Apps.launch(this, a) }
            v.setOnLongClickListener { appMenu(a); true }
            dock.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        dock.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        refreshDrawer()
    }

    private fun refreshDrawer() { drawerGrid.adapter = Adapter(drawerList(), true) }

    private fun appView(a: AppInfo, labels: Boolean): LinearLayout {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        val px = dp(Prefs.iconSize)
        l.addView(ImageView(this).apply { setImageBitmap(Icons.get(this@MainActivity, a, px)) }, LinearLayout.LayoutParams(px, px))
        if (labels && Prefs.labels) l.addView(tv(a.label, 11f).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, Color.BLACK); setPadding(dp(2), dp(4), dp(2), 0)
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        return l
    }

    inner class Adapter(private val l: List<AppInfo>, private val inDrawer: Boolean) : BaseAdapter() {
        override fun getCount() = l.size
        override fun getItem(p: Int) = l[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = l[p]; val v = appView(a, Prefs.labels)
            v.setOnClickListener { Apps.launch(this@MainActivity, a); if (inDrawer) closeDrawer() }
            v.setOnLongClickListener { appMenu(a); true }
            return v
        }
    }

    private fun appMenu(a: AppInfo) {
        val pins = Prefs.list("pins").toMutableList(); val dk = Prefs.list("dock").toMutableList()
        val opts = ArrayList<Pair<String, () -> Unit>>()
        fun add(t: String, f: () -> Unit) { opts.add(t to f) }
        if (a.pkg in pins) add("↩ إزالة من الشاشة الرئيسية") { pins.remove(a.pkg); Prefs.setList("pins", pins) }
        else add("📌 تثبيت في الشاشة الرئيسية") { pins.add(a.pkg); Prefs.setList("pins", pins) }
        if (a.pkg in dk) add("↩ إزالة من الدوك") { dk.remove(a.pkg); Prefs.setList("dock", dk) }
        else if (dk.size < 5) add("⚓ إضافة إلى الدوك") { dk.add(a.pkg); Prefs.setList("dock", dk) }
        add("🙈 إخفاء التطبيق") { Prefs.setList("hidden", Prefs.list("hidden") + a.pkg) }
        add("ℹ معلومات التطبيق") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        }
        add("🗑 إلغاء التثبيت") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) }
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(opts.map { it.first }.toTypedArray()) { _, i -> opts[i].second(); refreshLists() }.show()
    }

    private fun homeMenu() {
        val items = arrayOf("🖼 تغيير الخلفية", "📲 تعيين كخلفية للنظام", "⚙ إعدادات اللانشر")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> Util.pickWallpaper(this) { applyPrefs() }
                1 -> Util.setSystemWallpaper(this)
                else -> startActivity(Intent(this, SettingsActivity::class.java))
            }
        }.show()
    }

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = root.height.toFloat()
        drawer.animate().translationY(0f).setDuration(260).start()
        home.animate().alpha(0f).setDuration(200).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        home.animate().alpha(1f).setDuration(200).start()
        drawer.animate().translationY(root.height.toFloat()).setDuration(220).withEndAction {
            drawer.visibility = View.GONE; search.setText("")
        }.start()
    }

    private fun expandNotifications() {
        try {
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(getSystemService("statusbar"))
        } catch (e: Exception) {}
    }
}
