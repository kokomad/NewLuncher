package com.neonlauncher

import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.core.graphics.ColorUtils
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** ساعة تناظرية بتصميم نيون داكن مع توهج */
class AnalogClockView(c: Context) : View(c) {
    var accent: Int = DEFAULT_ACCENT
        set(v) { field = v; invalidate() }
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { invalidate(); ui.postDelayed(this, 1000) }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); ui.removeCallbacks(tick); ui.post(tick) }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); ui.removeCallbacks(tick) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = min(w, h) / 2f
        if (r <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val cal = Calendar.getInstance()
        val hr = cal.get(Calendar.HOUR); val mn = cal.get(Calendar.MINUTE); val sc = cal.get(Calendar.SECOND)

        // الوجه
        cv.drawCircle(cx, cy, r * 0.94f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, r * 0.95f, intArrayOf(0xFF1A1A1D.toInt(), 0xFF070708.toInt()),
                floatArrayOf(0.2f, 1f), Shader.TileMode.CLAMP)
        })
        // حلقة متوهجة
        cv.drawCircle(cx, cy, r * 0.92f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r * 0.05f
            color = (accent and 0x00FFFFFF) or 0x99000000.toInt()
            maskFilter = BlurMaskFilter(r * 0.06f, BlurMaskFilter.Blur.NORMAL)
        })
        cv.drawCircle(cx, cy, r * 0.92f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r * 0.018f; color = accent
        })

        // العلامات
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val major = i % 5 == 0
            val rr = r * 0.82f
            val x = cx + (rr * sin(a)).toFloat(); val y = cy - (rr * cos(a)).toFloat()
            dot.color = if (major) accent else 0x88FFFFFF.toInt()
            cv.drawCircle(x, y, if (major) r * 0.022f else r * 0.01f, dot)
        }

        // الأرقام الرئيسية
        val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = r * 0.15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val nr = r * 0.64f; val off = num.textSize * 0.35f
        cv.drawText("12", cx, cy - nr + off, num)
        cv.drawText("3", cx + nr, cy + off, num)
        cv.drawText("6", cx, cy + nr + off, num)
        cv.drawText("9", cx - nr, cy + off, num)

        // الوقت الرقمي الصغير
        val ar = Locale.getDefault().language == "ar"
        val pm = cal.get(Calendar.AM_PM) == Calendar.PM
        val ap = if (ar) (if (pm) "م" else "ص") else (if (pm) "PM" else "AM")
        val hh = if (hr == 0) 12 else hr
        cv.drawText(String.format(Locale.US, "%02d:%02d", hh, mn), cx, cy + r * 0.36f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textAlign = Paint.Align.CENTER; textSize = r * 0.14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        cv.drawText(ap, cx, cy + r * 0.48f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAAFFFFFF.toInt(); textAlign = Paint.Align.CENTER; textSize = r * 0.1f
        })

        // العقارب
        fun hand(deg: Double, len: Float, tail: Float, wd: Float, col: Int) {
            val a = Math.toRadians(deg)
            val dx = sin(a).toFloat(); val dy = -cos(a).toFloat()
            cv.drawLine(cx - dx * tail, cy - dy * tail, cx + dx * len, cy + dy * len, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = col; strokeWidth = wd; strokeCap = Paint.Cap.ROUND
            })
        }
        hand((hr + mn / 60.0) * 30.0, r * 0.46f, 0f, r * 0.055f, accent)
        hand((mn + sc / 60.0) * 6.0, r * 0.68f, 0f, r * 0.04f, Color.WHITE)
        hand(sc * 6.0, r * 0.78f, r * 0.15f, r * 0.016f, accent)
        cv.drawCircle(cx, cy, r * 0.05f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
        cv.drawCircle(cx, cy, r * 0.02f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0A0B.toInt() })
    }
}

/** خلفية الأمواج البرتقالية/الداكنة المطابقة لتصميم الواجهة */
class WaveBackgroundView(c: Context) : View(c) {
    var accent: Int = DEFAULT_ACCENT
        set(v) { if (field != v) { field = v; cache = null; invalidate() } }
    private var cache: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    private class Layer(val base: Float, val amp: Float, val freq: Float, val ph: Float,
                        val c1: Int, val c2: Int, val band: Float)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { cache = null }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return
        var b = cache
        if (b == null) { b = render(); cache = b }
        cv.drawBitmap(b, null, Rect(0, 0, width, height), paint)
    }

    private fun render(): Bitmap {
        val bw = (width * 0.5f).toInt().coerceAtLeast(2)
        val bh = (height * 0.5f).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val w = bw.toFloat(); val h = bh.toFloat()
        val dens = resources.displayMetrics.density * 0.5f

        val top = ColorUtils.blendARGB(accent, Color.WHITE, 0.10f)
        val bottom = ColorUtils.blendARGB(accent, Color.BLACK, 0.30f)
        c.drawRect(0f, 0f, w, h, Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h * 0.7f, top, bottom, Shader.TileMode.CLAMP)
        })

        val layers = listOf(
            Layer(0.44f, 0.028f, 1.1f, 0.4f, 0xFF232327.toInt(), 0xFF151517.toInt(), 5f),
            Layer(0.58f, 0.032f, 1.0f, 2.0f, 0xFF1A1A1D.toInt(), 0xFF101012.toInt(), 3.5f),
            Layer(0.72f, 0.030f, 1.3f, 3.6f, 0xFF131315.toInt(), 0xFF09090A.toInt(), 3f)
        )
        val steps = 90
        fun edge(l: Layer, offset: Float, close: Boolean): Path {
            val p = Path()
            for (i in 0..steps) {
                val t = i.toDouble() / steps
                val x = w * i / steps
                val y = h * l.base + h * l.amp * sin(2.0 * Math.PI * l.freq * t + l.ph).toFloat() - offset
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            if (close) { p.lineTo(w, h); p.lineTo(0f, h); p.close() }
            return p
        }
        for (l in layers) {
            val off = l.band * dens
            // توهج الحافة
            c.drawPath(edge(l, off, false), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 7f * dens
                color = (accent and 0x00FFFFFF) or 0xAA000000.toInt()
                maskFilter = BlurMaskFilter(10f * dens, BlurMaskFilter.Blur.NORMAL)
            })
            // الشريط البرتقالي
            c.drawPath(edge(l, off, true), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ColorUtils.blendARGB(accent, Color.WHITE, 0.08f)
            })
            // الطبقة الداكنة
            c.drawPath(edge(l, 0f, true), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, h * l.base, 0f, h, l.c1, l.c2, Shader.TileMode.CLAMP)
            })
            // لمعة رقيقة
            c.drawPath(edge(l, 0f, false), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 1f * dens; color = 0x22FFFFFF
            })
        }
        return bmp
    }
}

/** أيقونات متجهية مرسومة بالكود (بدون ملفات) */
class GlyphView(c: Context, k: Int) : View(c) {
    companion object {
        const val GRID = 0; const val HOME = 1; const val PERSON = 2; const val SEARCH = 3; const val WAVE = 4
        const val CAL = 5; const val CLOCK = 6; const val PIN = 7; const val SUN = 8; const val CLOUD = 9
        const val RAIN = 10; const val SNOW = 11; const val STORM = 12; const val MOON = 13
    }
    var kind: Int = k
        set(v) { field = v; invalidate() }
    var color: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

    private fun cloud(cv: Canvas, dy: Float) {
        p.style = Paint.Style.FILL
        val c = Path()
        c.addCircle(8f, 14f + dy, 3.6f, Path.Direction.CW)
        c.addCircle(12.8f, 10.8f + dy, 5f, Path.Direction.CW)
        c.addCircle(17f, 14.4f + dy, 3.6f, Path.Direction.CW)
        c.addRect(8f, 14f + dy, 17f, 17.6f + dy, Path.Direction.CW)
        cv.drawPath(c, p)
    }

    override fun onDraw(cv: Canvas) {
        val s = min(width, height) / 24f
        if (s <= 0f) return
        cv.save()
        cv.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        cv.scale(s, s)
        p.color = color; p.strokeWidth = 1.9f; p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> {
                p.style = Paint.Style.FILL
                for (i in 0..2) for (j in 0..2) cv.drawCircle(5f + i * 7f, 5f + j * 7f, 1.9f, p)
            }
            HOME -> {
                val roof = Path(); roof.moveTo(3f, 11f); roof.lineTo(12f, 3f); roof.lineTo(21f, 11f); cv.drawPath(roof, p)
                val b = Path(); b.moveTo(5f, 10f); b.lineTo(5f, 20f); b.lineTo(10f, 20f); b.lineTo(10f, 14f)
                b.lineTo(14f, 14f); b.lineTo(14f, 20f); b.lineTo(19f, 20f); b.lineTo(19f, 10f); cv.drawPath(b, p)
            }
            PERSON -> {
                cv.drawCircle(12f, 8f, 4f, p)
                val a = Path(); a.addArc(RectF(4f, 13f, 20f, 29f), 180f, 180f); cv.drawPath(a, p)
            }
            SEARCH -> {
                cv.drawCircle(10.5f, 10.5f, 6.5f, p); cv.drawLine(15.5f, 15.5f, 21f, 21f, p)
            }
            WAVE -> {
                cv.drawLine(4f, 10f, 4f, 14f, p); cv.drawLine(8f, 7f, 8f, 17f, p); cv.drawLine(12f, 3.5f, 12f, 20.5f, p)
                cv.drawLine(16f, 8f, 16f, 16f, p); cv.drawLine(20f, 10f, 20f, 14f, p)
            }
            CAL -> {
                cv.drawRoundRect(RectF(3.5f, 5f, 20.5f, 20.5f), 3f, 3f, p)
                cv.drawLine(3.5f, 10f, 20.5f, 10f, p); cv.drawLine(8f, 3f, 8f, 7f, p); cv.drawLine(16f, 3f, 16f, 7f, p)
            }
            CLOCK -> {
                cv.drawCircle(12f, 12f, 9f, p)
                val h = Path(); h.moveTo(12f, 6.5f); h.lineTo(12f, 12f); h.lineTo(16f, 14.5f); cv.drawPath(h, p)
            }
            PIN -> {
                val pt = Path(); pt.moveTo(12f, 22f)
                pt.cubicTo(12f, 22f, 5f, 14.5f, 5f, 9.5f); pt.cubicTo(5f, 5.6f, 8.1f, 2.5f, 12f, 2.5f)
                pt.cubicTo(15.9f, 2.5f, 19f, 5.6f, 19f, 9.5f); pt.cubicTo(19f, 14.5f, 12f, 22f, 12f, 22f); pt.close()
                cv.drawPath(pt, p); cv.drawCircle(12f, 9.5f, 2.5f, p)
            }
            SUN -> {
                p.style = Paint.Style.FILL; cv.drawCircle(12f, 12f, 4.5f, p); p.style = Paint.Style.STROKE
                for (i in 0..7) {
                    val a = Math.PI / 4 * i
                    cv.drawLine(12f + (7.5 * cos(a)).toFloat(), 12f + (7.5 * sin(a)).toFloat(),
                        12f + (10.5 * cos(a)).toFloat(), 12f + (10.5 * sin(a)).toFloat(), p)
                }
            }
            MOON -> {
                p.style = Paint.Style.FILL
                val a = Path(); a.addCircle(12f, 12f, 8f, Path.Direction.CW)
                val b = Path(); b.addCircle(16.5f, 8.5f, 7f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE); cv.drawPath(a, p)
            }
            CLOUD -> cloud(cv, 0f)
            RAIN -> {
                cloud(cv, -3f); p.style = Paint.Style.STROKE
                cv.drawLine(8f, 18.5f, 7f, 22f, p); cv.drawLine(12f, 18.5f, 11f, 22f, p); cv.drawLine(16f, 18.5f, 15f, 22f, p)
            }
            SNOW -> {
                cloud(cv, -3f)
                cv.drawCircle(8f, 20.5f, 1.1f, p); cv.drawCircle(12f, 21.5f, 1.1f, p); cv.drawCircle(16f, 20.5f, 1.1f, p)
            }
            STORM -> {
                cloud(cv, -3f)
                val bo = Path(); bo.moveTo(13f, 15.5f); bo.lineTo(9.5f, 20.5f); bo.lineTo(12.3f, 20.5f)
                bo.lineTo(11f, 24f); bo.lineTo(16f, 18.5f); bo.lineTo(13f, 18.5f); bo.close(); cv.drawPath(bo, p)
            }
        }
        cv.restore()
    }
}


/** بارالاكس بالحساس: يرسل إزاحة مطبّعة (-1..1) حسب ميلان الجهاز */
class Parallax(ctx: Context, private val onMove: (Float, Float) -> Unit) : SensorEventListener {
    private val sm = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var bx = 0f; private var by = 0f
    private var cx = 0f; private var cy = 0f
    private var ready = false
    private var on = false

    fun start() {
        if (on) return
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        ready = false; on = true
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() { if (on) { sm.unregisterListener(this); on = false } }

    override fun onSensorChanged(e: SensorEvent) {
        val x = (e.values[0] / 9.81f).coerceIn(-1f, 1f)
        val y = (e.values[1] / 9.81f).coerceIn(-1f, 1f)
        if (!ready) { bx = x; by = y; ready = true }
        bx += (x - bx) * 0.01f; by += (y - by) * 0.01f      // خط أساس يتكيف مع طريقة إمساك الجهاز
        cx += ((x - bx) - cx) * 0.12f; cy += ((y - by) - cy) * 0.12f
        onMove((cx * 3f).coerceIn(-1f, 1f), (cy * 3f).coerceIn(-1f, 1f))
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
