package com.neonlauncher

import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** ساعة تناظرية بتصميم نيون داكن مع توهج */
class AnalogClockView(c: Context) : View(c) {
    var accent: Int = DEFAULT_ACCENT
        set(v) { field = v; invalidate() }
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { invalidate(); ui.postDelayed(this, 1000) }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); ui.removeCallbacks(tick); ui.post(tick) }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); ui.removeCallbacks(tick) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = min(w, h) / 2f
        if (r <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val cal = Calendar.getInstance()
        val hr = cal.get(Calendar.HOUR); val mn = cal.get(Calendar.MINUTE); val sc = cal.get(Calendar.SECOND)

        // الوجه
        cv.drawCircle(cx, cy, r * 0.94f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, r * 0.95f, intArrayOf(0xFF1A1A1D.toInt(), 0xFF070708.toInt()),
                floatArrayOf(0.2f, 1f), Shader.TileMode.CLAMP)
        })
        // حلقة متوهجة
        cv.drawCircle(cx, cy, r * 0.92f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r * 0.05f
            color = (accent and 0x00FFFFFF) or 0x99000000.toInt()
            maskFilter = BlurMaskFilter(r * 0.06f, BlurMaskFilter.Blur.NORMAL)
        })
        cv.drawCircle(cx, cy, r * 0.92f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r * 0.018f; color = accent
        })

        // العلامات
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val major = i % 5 == 0
            val rr = r * 0.82f
            val x = cx + (rr * sin(a)).toFloat(); val y = cy - (rr * cos(a)).toFloat()
            dot.color = if (major) accent else 0x88FFFFFF.toInt()
            cv.drawCircle(x, y, if (major) r * 0.022f else r * 0.01f, dot)
        }

        // الأرقام الرئيسية
        val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = r * 0.15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val nr = r * 0.64f; val off = num.textSize * 0.35f
        cv.drawText("12", cx, cy - nr + off, num)
        cv.drawText("3", cx + nr, cy + off, num)
        cv.drawText("6", cx, cy + nr + off, num)
        cv.drawText("9", cx - nr, cy + off, num)

        // الوقت الرقمي الصغير
        val ar = Locale.getDefault().language == "ar"
        val pm = cal.get(Calendar.AM_PM) == Calendar.PM
        val ap = if (ar) (if (pm) "م" else "ص") else (if (pm) "PM" else "AM")
        val hh = if (hr == 0) 12 else hr
        cv.drawText(String.format(Locale.US, "%02d:%02d", hh, mn), cx, cy + r * 0.36f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textAlign = Paint.Align.CENTER; textSize = r * 0.14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        cv.drawText(ap, cx, cy + r * 0.48f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAAFFFFFF.toInt(); textAlign = Paint.Align.CENTER; textSize = r * 0.1f
        })

        // العقارب
        fun hand(deg: Double, len: Float, tail: Float, wd: Float, col: Int) {
            val a = Math.toRadians(deg)
            val dx = sin(a).toFloat(); val dy = -cos(a).toFloat()
            cv.drawLine(cx - dx * tail, cy - dy * tail, cx + dx * len, cy + dy * len, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = col; strokeWidth = wd; strokeCap = Paint.Cap.ROUND
            })
        }
        hand((hr + mn / 60.0) * 30.0, r * 0.46f, 0f, r * 0.055f, accent)
        hand((mn + sc / 60.0) * 6.0, r * 0.68f, 0f, r * 0.04f, Color.WHITE)
        hand(sc * 6.0, r * 0.78f, r * 0.15f, r * 0.016f, accent)
        cv.drawCircle(cx, cy, r * 0.05f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
        cv.drawCircle(cx, cy, r * 0.02f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0A0B.toInt() })
    }
}

/** خلفية الأمواج البرتقالية/الداكنة المطابقة لتصميم الواجهة */
class WaveBackgroundView(c: Context) : View(c) {
    var accent: Int = DEFAULT_ACCENT
        set(v) { if (field != v) { field = v; cache = null; invalidate() } }
    private var cache: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    private class Layer(val base: Float, val amp: Float, val freq: Float, val ph: Float,
                        val c1: Int, val c2: Int, val band: Float)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { cache = null }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return
        var b = cache
        if (b == null) { b = render(); cache = b }
        cv.drawBitmap(b, null, Rect(0, 0, width, height), paint)
    }

    var style: Int = Themes.CLASSIC
        set(v) { if (field != v) { field = v; cache = null; invalidate() } }

    private fun pt(f: Paint.() -> Unit) = Paint(Paint.ANTI_ALIAS_FLAG).apply(f)

    private fun render(): Bitmap {
        val bw = (width * 0.5f).toInt().coerceAtLeast(2)
        val bh = (height * 0.5f).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val w = bw.toFloat(); val h = bh.toFloat()
        val dens = resources.displayMetrics.density * 0.5f
        when (style) {
            0 -> glassBlobs(c, w, h, dens)
            1 -> monoCurve(c, w, h, dens)
            2 -> goldPeel(c, w, h, dens)
            3 -> blueSheet(c, w, h, dens)
            4 -> launcherCurve(c, w, h, dens)
            else -> classicWaves(c, w, h, dens)
        }
        return bmp
    }

    // ===== 0: فقاعات زجاجية برتقالية مع فقاعة بيضاء =====
    private fun glassBlobs(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, pt { shader = LinearGradient(0f, 0f, w * 0.3f, h, 0xFFFFB766.toInt(), 0xFFEB8A32.toInt(), Shader.TileMode.CLAMP) })
        val plate = RectF(w * 0.16f, h * 0.155f, w * 0.84f, h * 0.855f)
        c.drawRoundRect(plate, w * 0.1f, w * 0.1f, pt { color = 0x33D9621A })
        c.drawRoundRect(plate, w * 0.1f, w * 0.1f, pt { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = 0x44FFFFFF })
        val th = h * 0.19f
        fun blob(cy: Float, amp: Float, top: Int, bot: Int, rim: Int) {
            val x0 = w * 0.13f + th / 2f; val x1 = w * 0.87f - th / 2f
            val p = Path()
            for (i in 0..60) {
                val t = i / 60f
                val x = x0 + (x1 - x0) * t
                val y = cy + amp * cos(Math.PI * t).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            c.save(); c.translate(th * 0.06f, th * 0.16f)
            c.drawPath(p, pt { style = Paint.Style.STROKE; strokeWidth = th; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                color = 0x55A04000; maskFilter = BlurMaskFilter(th * 0.14f, BlurMaskFilter.Blur.NORMAL) })
            c.restore()
            c.drawPath(p, pt { style = Paint.Style.STROKE; strokeWidth = th + 3f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = rim })
            c.drawPath(p, pt { style = Paint.Style.STROKE; strokeWidth = th; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                shader = LinearGradient(0f, cy - amp - th / 2f, 0f, cy + amp + th / 2f, top, bot, Shader.TileMode.CLAMP) })
            c.save(); c.translate(0f, -th * 0.2f)
            c.drawPath(p, pt { style = Paint.Style.STROKE; strokeWidth = th * 0.42f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = 0x33FFFFFF })
            c.restore()
        }
        blob(h * 0.29f, h * 0.04f, 0xFFFFA83A.toInt(), 0xFFF28A1E.toInt(), 0x88FFE2B8.toInt())
        blob(h * 0.50f, h * 0.04f, 0xFFFFFFFF.toInt(), 0xFFEFEFEF.toInt(), 0xAAFFFFFF.toInt())
        blob(h * 0.71f, h * 0.04f, 0xFFF59A2B.toInt(), 0xFFE5791A.toInt(), 0x88FFE2B8.toInt())
    }

    // ===== 1: منحنى S أسود/أبيض =====
    private fun monoCurve(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, pt { shader = LinearGradient(w, 0f, 0f, h, 0xFFFBF9FB.toInt(), 0xFFD6D6D8.toInt(), Shader.TileMode.CLAMP) })
        val p = Path()
        p.moveTo(w * 0.36f, 0f)
        p.cubicTo(w * 0.06f, h * 0.10f, w * 0.14f, h * 0.38f, w * 0.40f, h * 0.54f)
        p.cubicTo(w * 0.66f, h * 0.70f, w * 0.80f, h * 0.80f, w * 0.64f, h)
        p.lineTo(0f, h); p.lineTo(0f, 0f); p.close()
        c.drawPath(p, pt { color = 0xFF060A07.toInt(); setShadowLayer(14f * d, 4f * d, 0f, 0x55000000) })
    }

    // ===== 2: ورقة ذهبية مقشورة فوق خلفية زرقاء =====
    private fun goldPeel(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, pt { shader = LinearGradient(w, 0f, 0f, h * 0.5f, 0xFF0A14FF.toInt(), 0xFF0020C8.toInt(), Shader.TileMode.CLAMP) })
        val sheet = Path()
        sheet.moveTo(0f, h * 0.07f); sheet.lineTo(w, h * 0.78f); sheet.lineTo(w, h); sheet.lineTo(0f, h); sheet.close()
        c.drawPath(sheet, pt { shader = LinearGradient(0f, h * 0.3f, w, h, 0xFFFFC400.toInt(), 0xFFFFA800.toInt(), Shader.TileMode.CLAMP) })
        val flap = Path()
        flap.moveTo(w * 0.23f, h * 0.233f); flap.lineTo(w, h * 0.78f)
        flap.cubicTo(w * 0.86f, h * 0.76f, w * 0.52f, h * 0.70f, w * 0.34f, h * 0.60f)
        flap.cubicTo(w * 0.21f, h * 0.52f, w * 0.20f, h * 0.38f, w * 0.23f, h * 0.233f)
        flap.close()
        c.save(); c.translate(-w * 0.02f, h * 0.012f)
        c.drawPath(flap, pt { color = 0xAA6B2E00.toInt(); maskFilter = BlurMaskFilter(14f * d, BlurMaskFilter.Blur.NORMAL) })
        c.restore()
        c.drawPath(flap, pt { shader = LinearGradient(w * 0.7f, h * 0.45f, w * 0.3f, h * 0.68f, 0xFFFFD84D.toInt(), 0xFFE08A00.toInt(), Shader.TileMode.CLAMP) })
    }

    // ===== 3: أزرق ملكي ناعم (البطاقة تحمل مظهر الورقة) =====
    private fun blueSheet(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, pt { shader = LinearGradient(0f, 0f, 0f, h, 0xFF0B42F0.toInt(), 0xFF002FC4.toInt(), Shader.TileMode.CLAMP) })
        c.drawCircle(w * 0.85f, h * 0.18f, w * 0.9f, pt {
            shader = RadialGradient(w * 0.85f, h * 0.18f, w * 0.9f, 0x44FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP) })
        c.drawCircle(w * 0.1f, h * 0.95f, w * 0.8f, pt {
            shader = RadialGradient(w * 0.1f, h * 0.95f, w * 0.8f, 0x55000A60, 0x00000A60, Shader.TileMode.CLAMP) })
    }

    // ===== 4: منحنى اللانشر المرجعي (رمادي + خطان أزرقان + أسود) =====
    private fun launcherCurve(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, pt { shader = LinearGradient(0f, 0f, w, h, 0xFFCBCBCD.toInt(), 0xFFAEAEB2.toInt(), Shader.TileMode.CLAMP) })
        fun curve(dx: Float): Path {
            val p = Path()
            p.moveTo(w * 0.50f + dx, 0f)
            p.cubicTo(w * 0.82f + dx, h * 0.20f, w * 0.66f + dx, h * 0.60f, w * 0.30f + dx, h)
            return p
        }
        c.drawPath(curve(-w * 0.045f), pt { style = Paint.Style.STROKE; strokeWidth = w * 0.05f; color = 0xFF2AA3E8.toInt() })
        c.drawPath(curve(-w * 0.015f), pt { style = Paint.Style.STROKE; strokeWidth = w * 0.03f; color = 0xFF0A4BB8.toInt() })
        val black = curve(0f)
        black.lineTo(w, h); black.lineTo(w, 0f); black.close()
        c.drawPath(black, pt { shader = LinearGradient(w * 0.5f, 0f, w, h, 0xFF101012.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP) })
    }

    // ===== 5: الأمواج الأصلية =====
    private fun classicWaves(c: Canvas, w: Float, h: Float, dens: Float) {
        val top = ColorUtils.blendARGB(accent, Color.WHITE, 0.10f)
        val bottom = ColorUtils.blendARGB(accent, Color.BLACK, 0.30f)
        c.drawRect(0f, 0f, w, h, Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h * 0.7f, top, bottom, Shader.TileMode.CLAMP)
        })

        val layers = listOf(
            Layer(0.44f, 0.028f, 1.1f, 0.4f, 0xFF232327.toInt(), 0xFF151517.toInt(), 5f),
            Layer(0.58f, 0.032f, 1.0f, 2.0f, 0xFF1A1A1D.toInt(), 0xFF101012.toInt(), 3.5f),
            Layer(0.72f, 0.030f, 1.3f, 3.6f, 0xFF131315.toInt(), 0xFF09090A.toInt(), 3f)
        )
        val steps = 90
        fun edge(l: Layer, offset: Float, close: Boolean): Path {
            val p = Path()
            for (i in 0..steps) {
                val t = i.toDouble() / steps
                val x = w * i / steps
                val y = h * l.base + h * l.amp * sin(2.0 * Math.PI * l.freq * t + l.ph).toFloat() - offset
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            if (close) { p.lineTo(w, h); p.lineTo(0f, h); p.close() }
            return p
        }
        for (l in layers) {
            val off = l.band * dens
            // توهج الحافة
            c.drawPath(edge(l, off, false), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 7f * dens
                color = (accent and 0x00FFFFFF) or 0xAA000000.toInt()
                maskFilter = BlurMaskFilter(10f * dens, BlurMaskFilter.Blur.NORMAL)
            })
            // الشريط البرتقالي
            c.drawPath(edge(l, off, true), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ColorUtils.blendARGB(accent, Color.WHITE, 0.08f)
            })
            // الطبقة الداكنة
            c.drawPath(edge(l, 0f, true), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, h * l.base, 0f, h, l.c1, l.c2, Shader.TileMode.CLAMP)
            })
            // لمعة رقيقة
            c.drawPath(edge(l, 0f, false), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 1f * dens; color = 0x22FFFFFF
            })
        }
    }
}

/** أيقونات متجهية مرسومة بالكود (بدون ملفات) */
class GlyphView(c: Context, k: Int) : View(c) {
    companion object {
        const val GRID = 0; const val HOME = 1; const val PERSON = 2; const val SEARCH = 3; const val WAVE = 4
        const val CAL = 5; const val CLOCK = 6; const val PIN = 7; const val SUN = 8; const val CLOUD = 9
        const val RAIN = 10; const val SNOW = 11; const val STORM = 12; const val MOON = 13
    }
    var kind: Int = k
        set(v) { field = v; invalidate() }
    var color: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

    private fun cloud(cv: Canvas, dy: Float) {
        p.style = Paint.Style.FILL
        val c = Path()
        c.addCircle(8f, 14f + dy, 3.6f, Path.Direction.CW)
        c.addCircle(12.8f, 10.8f + dy, 5f, Path.Direction.CW)
        c.addCircle(17f, 14.4f + dy, 3.6f, Path.Direction.CW)
        c.addRect(8f, 14f + dy, 17f, 17.6f + dy, Path.Direction.CW)
        cv.drawPath(c, p)
    }

    override fun onDraw(cv: Canvas) {
        val s = min(width, height) / 24f
        if (s <= 0f) return
        cv.save()
        cv.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        cv.scale(s, s)
        p.color = color; p.strokeWidth = 1.9f; p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> {
                p.style = Paint.Style.FILL
                for (i in 0..2) for (j in 0..2) cv.drawCircle(5f + i * 7f, 5f + j * 7f, 1.9f, p)
            }
            HOME -> {
                val roof = Path(); roof.moveTo(3f, 11f); roof.lineTo(12f, 3f); roof.lineTo(21f, 11f); cv.drawPath(roof, p)
                val b = Path(); b.moveTo(5f, 10f); b.lineTo(5f, 20f); b.lineTo(10f, 20f); b.lineTo(10f, 14f)
                b.lineTo(14f, 14f); b.lineTo(14f, 20f); b.lineTo(19f, 20f); b.lineTo(19f, 10f); cv.drawPath(b, p)
            }
            PERSON -> {
                cv.drawCircle(12f, 8f, 4f, p)
                val a = Path(); a.addArc(RectF(4f, 13f, 20f, 29f), 180f, 180f); cv.drawPath(a, p)
            }
            SEARCH -> {
                cv.drawCircle(10.5f, 10.5f, 6.5f, p); cv.drawLine(15.5f, 15.5f, 21f, 21f, p)
            }
            WAVE -> {
                cv.drawLine(4f, 10f, 4f, 14f, p); cv.drawLine(8f, 7f, 8f, 17f, p); cv.drawLine(12f, 3.5f, 12f, 20.5f, p)
                cv.drawLine(16f, 8f, 16f, 16f, p); cv.drawLine(20f, 10f, 20f, 14f, p)
            }
            CAL -> {
                cv.drawRoundRect(RectF(3.5f, 5f, 20.5f, 20.5f), 3f, 3f, p)
                cv.drawLine(3.5f, 10f, 20.5f, 10f, p); cv.drawLine(8f, 3f, 8f, 7f, p); cv.drawLine(16f, 3f, 16f, 7f, p)
            }
            CLOCK -> {
                cv.drawCircle(12f, 12f, 9f, p)
                val h = Path(); h.moveTo(12f, 6.5f); h.lineTo(12f, 12f); h.lineTo(16f, 14.5f); cv.drawPath(h, p)
            }
            PIN -> {
                val pt = Path(); pt.moveTo(12f, 22f)
                pt.cubicTo(12f, 22f, 5f, 14.5f, 5f, 9.5f); pt.cubicTo(5f, 5.6f, 8.1f, 2.5f, 12f, 2.5f)
                pt.cubicTo(15.9f, 2.5f, 19f, 5.6f, 19f, 9.5f); pt.cubicTo(19f, 14.5f, 12f, 22f, 12f, 22f); pt.close()
                cv.drawPath(pt, p); cv.drawCircle(12f, 9.5f, 2.5f, p)
            }
            SUN -> {
                p.style = Paint.Style.FILL; cv.drawCircle(12f, 12f, 4.5f, p); p.style = Paint.Style.STROKE
                for (i in 0..7) {
                    val a = Math.PI / 4 * i
                    cv.drawLine(12f + (7.5 * cos(a)).toFloat(), 12f + (7.5 * sin(a)).toFloat(),
                        12f + (10.5 * cos(a)).toFloat(), 12f + (10.5 * sin(a)).toFloat(), p)
                }
            }
            MOON -> {
                p.style = Paint.Style.FILL
                val a = Path(); a.addCircle(12f, 12f, 8f, Path.Direction.CW)
                val b = Path(); b.addCircle(16.5f, 8.5f, 7f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE); cv.drawPath(a, p)
            }
            CLOUD -> cloud(cv, 0f)
            RAIN -> {
                cloud(cv, -3f); p.style = Paint.Style.STROKE
                cv.drawLine(8f, 18.5f, 7f, 22f, p); cv.drawLine(12f, 18.5f, 11f, 22f, p); cv.drawLine(16f, 18.5f, 15f, 22f, p)
            }
            SNOW -> {
                cloud(cv, -3f)
                cv.drawCircle(8f, 20.5f, 1.1f, p); cv.drawCircle(12f, 21.5f, 1.1f, p); cv.drawCircle(16f, 20.5f, 1.1f, p)
            }
            STORM -> {
                cloud(cv, -3f)
                val bo = Path(); bo.moveTo(13f, 15.5f); bo.lineTo(9.5f, 20.5f); bo.lineTo(12.3f, 20.5f)
                bo.lineTo(11f, 24f); bo.lineTo(16f, 18.5f); bo.lineTo(13f, 18.5f); bo.close(); cv.drawPath(bo, p)
            }
        }
        cv.restore()
    }
}


/** بارالاكس بالحساس: يرسل إزاحة مطبّعة (-1..1) حسب ميلان الجهاز */
class Parallax(ctx: Context, private val onMove: (Float, Float) -> Unit) : SensorEventListener {
    private val sm = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var bx = 0f; private var by = 0f
    private var cx = 0f; private var cy = 0f
    private var ready = false
    private var on = false

    fun start() {
        if (on) return
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        ready = false; on = true
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() { if (on) { sm.unregisterListener(this); on = false } }

    override fun onSensorChanged(e: SensorEvent) {
        val x = (e.values[0] / 9.81f).coerceIn(-1f, 1f)
        val y = (e.values[1] / 9.81f).coerceIn(-1f, 1f)
        if (!ready) { bx = x; by = y; ready = true }
        bx += (x - bx) * 0.01f; by += (y - by) * 0.01f      // خط أساس يتكيف مع طريقة إمساك الجهاز
        cx += ((x - bx) - cx) * 0.12f; cy += ((y - by) - cy) * 0.12f
        onMove((cx * 3f).coerceIn(-1f, 1f), (cy * 3f).coerceIn(-1f, 1f))
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}


/** شبكة تأخذ ارتفاع محتواها كاملاً لتوضع داخل ScrollView */
class NoScrollGrid(c: Context) : android.widget.GridView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(Int.MAX_VALUE shr 2, View.MeasureSpec.AT_MOST))
    }
}


/** صفحات تدور كمكعب ثلاثي الأبعاد عند السحب أفقياً */
class CubePager(c: Context) : FrameLayout(c) {
    var pos = 0f
        private set
    var locked = false
    var listener: ((Float) -> Unit)? = null
    private val slop = ViewConfiguration.get(c).scaledTouchSlop
    private var startX = 0f; private var startY = 0f; private var lastX = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null

    fun atHome() = abs(pos) < 0.001f
    fun page() = pos.roundToInt()

    fun goTo(i: Int, animate: Boolean = true) {
        val t = i.coerceIn(0, (childCount - 1).coerceAtLeast(0)).toFloat()
        anim?.cancel()
        if (!animate || width == 0) { setPos(t); return }
        anim = ValueAnimator.ofFloat(pos, t).apply {
            duration = 320; interpolator = DecelerateInterpolator()
            addUpdateListener { setPos(it.animatedValue as Float) }
            start()
        }
    }

    private fun setPos(p: Float) {
        pos = p.coerceIn(0f, (childCount - 1).coerceAtLeast(0).toFloat())
        applyTransforms(); listener?.invoke(pos)
    }

    private fun applyTransforms() {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val cd = 12000f * resources.displayMetrics.density
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val off = i - pos
            if (abs(off) >= 1f) { v.visibility = View.INVISIBLE; continue }
            v.visibility = View.VISIBLE
            v.cameraDistance = cd
            v.pivotX = if (off < 0f) w else 0f
            v.pivotY = h / 2f
            v.translationX = off * w
            v.rotationY = 90f * off
            v.alpha = (1f - 0.6f * abs(off)).coerceIn(0f, 1f)
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b); applyTransforms()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (locked || childCount < 2) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = e.x; startY = e.y; lastX = e.x; dragging = false; anim?.cancel()
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - startX; val dy = e.y - startY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy) * 1.3f) {
                    dragging = true; lastX = e.x
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { vt?.recycle(); vt = null }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked || childCount < 2) return false
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = e.x; startY = e.y; lastX = e.x; dragging = false
                if (vt == null) vt = VelocityTracker.obtain()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && width > 0) {
                    val dx = e.x - lastX; lastX = e.x
                    setPos(pos - dx / width)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val target = when {
                        vx < -800f -> floor(pos) + 1f
                        vx > 800f -> ceil(pos) - 1f
                        else -> pos.roundToInt().toFloat()
                    }
                    goTo(target.toInt())
                }
                dragging = false; vt?.recycle(); vt = null
            }
        }
        return true
    }
}
